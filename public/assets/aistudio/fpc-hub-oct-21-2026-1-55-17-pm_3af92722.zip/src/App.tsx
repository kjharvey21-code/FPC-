import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AuthScreen } from './components/AuthScreen';
import { TopNav } from './components/TopNav';
import { BottomNav } from './components/BottomNav';
import { ToastContainer } from './components/ToastContainer';
import { HomeTab } from './components/tabs/HomeTab';
import { FeedTab } from './components/tabs/FeedTab';
import { ProfileTab } from './components/tabs/ProfileTab';
import { AdminTab } from './components/tabs/AdminTab';

const MainLayout: React.FC = () => {
  const { currentUser, activeTab } = useApp();

  if (!currentUser) {
    return (
      <>
        <AuthScreen />
        <ToastContainer />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-300">
      {/* Top Bar following Top Bar Contract */}
      <TopNav />

      {/* Main Responsive Canvas */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 md:py-8">
        {activeTab === 'home' && <HomeTab />}
        {activeTab === 'feed' && <FeedTab />}
        {activeTab === 'profile' && <ProfileTab />}
        {activeTab === 'admin' && <AdminTab />}
      </main>

      {/* Mobile-first Reclub Bottom Navigation */}
      <BottomNav />

      {/* Global Notifications */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
