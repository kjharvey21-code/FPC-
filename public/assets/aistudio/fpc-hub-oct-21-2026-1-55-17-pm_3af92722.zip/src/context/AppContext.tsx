import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  ContestSubmission,
  EventAssignment,
  FeedPost,
  MLogEntry,
  SystemSettings,
  User,
  UserRole,
  OfficerRole,
  RankTier,
} from '../types';
import {
  INITIAL_CONTEST_SUBMISSIONS,
  INITIAL_EVENTS,
  INITIAL_FEED_POSTS,
  INITIAL_MLOG_ENTRIES,
  INITIAL_SETTINGS,
  INITIAL_USERS,
} from '../data/mockData';
import {
  calculatePksFromCodes,
  isElevatedRole,
  getRankTierForPks,
  getNextRankProgress,
} from '../data/pksFramework';

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  // Auth & Session
  currentUser: User | null;
  login: (username: string, password: string) => { success: boolean; message?: string };
  logout: () => void;
  switchUser: (userId: string) => void;
  allUsers: User[];

  // Navigation
  activeTab: 'home' | 'feed' | 'profile' | 'admin';
  setActiveTab: (tab: 'home' | 'feed' | 'profile' | 'admin') => void;

  // System Settings (SuperAdmin)
  systemSettings: SystemSettings;
  updateSystemSettings: (updates: Partial<SystemSettings>) => boolean;

  // Members & Roles (Dual Status Support & Dynamic Rank)
  addMember: (memberData: Omit<User, 'id'>, initialPks?: number) => void;
  updateMemberRole: (memberId: string, newRole: UserRole, isOfficer?: boolean) => void;
  updateMemberDualRoles: (
    memberId: string,
    officerRole: OfficerRole,
    projectHeadRoles?: string[],
    isOfficer?: boolean
  ) => void;
  updateMemberProfile: (memberId: string, updates: Partial<User>) => void;
  getMemberPks: (memberId: string) => number;
  getMemberRank: (memberId: string) => RankTier;
  getMemberProgress: (memberId: string) => ReturnType<typeof getNextRankProgress>;
  getMemberPillarBreakdown: (memberId: string) => { C: number; P: number; B: number; R: number; S: number };

  // M.Log Entries
  mLogEntries: MLogEntry[];
  addManualMLogEntry: (entry: Omit<MLogEntry, 'id' | 'submittedAt'>) => void;
  submitMemberMLogRequest: (request: {
    eventTitle: string;
    roleOrAward: string;
    codes: string[];
    remarks: string;
    proofUrl?: string;
  }) => void;
  verifyMLogEntry: (entryId: string, status: 'verified' | 'rejected', notes?: string) => void;
  updateMLogEntry: (entryId: string, updates: Partial<MLogEntry>) => void;
  deleteMLogEntry: (entryId: string) => void;

  // Events & Contests
  events: EventAssignment[];
  createEvent: (eventData: Omit<EventAssignment, 'id' | 'assignedCrewIds' | 'volunteerCrewIds' | 'submittedEntriesCount'>) => void;
  toggleVolunteer: (eventId: string) => void;
  assignCrew: (eventId: string, memberIds: string[]) => void;
  updateEventStatus: (eventId: string, status: 'upcoming' | 'ongoing' | 'completed') => void;

  // Contest Submissions
  contestSubmissions: ContestSubmission[];
  submitToContest: (submission: {
    eventId: string;
    eventTitle: string;
    title: string;
    caption: string;
    imageUrl: string;
  }) => void;
  reviewSubmission: (
    submissionId: string,
    status: 'approved' | 'featured' | 'rejected',
    awardWon?: string,
    awardPksCodes?: string[]
  ) => void;

  // Feed
  feedPosts: FeedPost[];
  createFeedPost: (postData: Omit<FeedPost, 'id' | 'publishedAt' | 'applauseCount'>) => void;
  applaudPost: (postId: string) => void;

  // Feedback Toasts
  toasts: ToastNotification[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SETTINGS: 'fpc_hub_settings_v1',
  USERS: 'fpc_hub_users_v1',
  CURRENT_USER_ID: 'fpc_hub_current_user_id_v1',
  EVENTS: 'fpc_hub_events_v1',
  MLOG: 'fpc_hub_mlog_v1',
  FEED: 'fpc_hub_feed_v1',
  SUBMISSIONS: 'fpc_hub_submissions_v1',
};

const safeLocalStorageSet = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`LocalStorage quota exceeded for ${key}, initiating recovery:`, err);
    try {
      // Level 1: Sanitize large data URLs
      if (Array.isArray(value)) {
        const lean = value.map((item) => {
          if (item && typeof item === 'object') {
            const copy = { ...(item as Record<string, unknown>) };
            if (
              typeof copy.proofUrl === 'string' &&
              copy.proofUrl.startsWith('data:')
            ) {
              copy.proofUrl = '/src/assets/images/fpc_event_intramurals_1792558823605.jpg';
            }
            if (
              typeof copy.imageUrl === 'string' &&
              copy.imageUrl.startsWith('data:')
            ) {
              copy.imageUrl = '/src/assets/images/fpc_contest_streetphoto_1792558823968.jpg';
            }
            return copy;
          }
          return item;
        });
        localStorage.setItem(key, JSON.stringify(lean));
        return;
      }
    } catch {
      // Level 2: Free space by removing non-critical keys
      try {
        localStorage.removeItem(STORAGE_KEYS.FEED);
        localStorage.removeItem(STORAGE_KEYS.SUBMISSIONS);
        localStorage.setItem(key, JSON.stringify(value));
      } catch {
        // Level 3: Gracefully allow in-memory state without crashing
        console.warn(`Could not persist ${key} to localStorage; state remains in memory.`);
      }
    }
  }
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize from localStorage or defaults
  const [systemSettings, setSystemSettings] = useState<SystemSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [allUsers, setAllUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USERS);
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID) || null;
    } catch {
      return null;
    }
  });

  const [events, setEvents] = useState<EventAssignment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EVENTS);
      return saved ? JSON.parse(saved) : INITIAL_EVENTS;
    } catch {
      return INITIAL_EVENTS;
    }
  });

  const [mLogEntries, setMLogEntries] = useState<MLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MLOG);
      return saved ? JSON.parse(saved) : INITIAL_MLOG_ENTRIES;
    } catch {
      return INITIAL_MLOG_ENTRIES;
    }
  });

  const [contestSubmissions, setContestSubmissions] = useState<ContestSubmission[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUBMISSIONS);
      return saved ? JSON.parse(saved) : INITIAL_CONTEST_SUBMISSIONS;
    } catch {
      return INITIAL_CONTEST_SUBMISSIONS;
    }
  });

  const [feedPosts, setFeedPosts] = useState<FeedPost[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FEED);
      return saved ? JSON.parse(saved) : INITIAL_FEED_POSTS;
    } catch {
      return INITIAL_FEED_POSTS;
    }
  });

  const [activeTab, setActiveTab] = useState<'home' | 'feed' | 'profile' | 'admin'>('home');
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Persist state updates safely without throwing unhandled QuotaExceededError
  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.SETTINGS, systemSettings);
  }, [systemSettings]);

  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.USERS, allUsers);
  }, [allUsers]);

  useEffect(() => {
    try {
      if (currentUserId) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, currentUserId);
      } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
      }
    } catch (e) {
      console.warn('Failed to save current user id', e);
    }
  }, [currentUserId]);

  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.EVENTS, events);
  }, [events]);

  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.MLOG, mLogEntries);
  }, [mLogEntries]);

  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.SUBMISSIONS, contestSubmissions);
  }, [contestSubmissions]);

  useEffect(() => {
    safeLocalStorageSet(STORAGE_KEYS.FEED, feedPosts);
  }, [feedPosts]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const currentUser = allUsers.find((u) => u.id === currentUserId) || null;

  // Authentication
  const login = (usernameInput: string, passwordInput: string) => {
    const trimmedUsername = usernameInput.trim().toLowerCase();
    const user = allUsers.find(
      (u) =>
        u.username.toLowerCase() === trimmedUsername &&
        (u.password ? u.password === passwordInput : passwordInput === 'fpc2026')
    );

    if (user) {
      setCurrentUserId(user.id);
      showToast(`Welcome back, ${user.nickname}!`, 'success');
      return { success: true };
    }
    return {
      success: false,
      message: 'Invalid username or password. Please verify with an FPC Administrator.',
    };
  };

  const logout = () => {
    setCurrentUserId(null);
    setActiveTab('home');
    showToast('You have been logged out safely.', 'info');
  };

  const switchUser = (userId: string) => {
    const target = allUsers.find((u) => u.id === userId);
    if (target) {
      setCurrentUserId(target.id);
      showToast(`Switched active view to ${target.nickname} (${target.role})`, 'info');
    }
  };

  // SuperAdmin global settings control
  const updateSystemSettings = (updates: Partial<SystemSettings>): boolean => {
    if (currentUser?.role !== 'SuperAdmin') {
      showToast('Unauthorized: Only SuperAdmin can modify global system settings.', 'error');
      return false;
    }
    setSystemSettings((prev) => ({ ...prev, ...updates }));
    showToast('System settings updated successfully.', 'success');
    return true;
  };

  // Dynamic PKS & Automatic Rank Calculations
  const getMemberPks = (memberId: string): number => {
    return mLogEntries
      .filter((entry) => entry.memberId === memberId && entry.status === 'verified')
      .reduce((acc, curr) => acc + curr.totalPoints, 0);
  };

  const getMemberRank = (memberId: string): RankTier => {
    const points = getMemberPks(memberId);
    return getRankTierForPks(points);
  };

  const getMemberProgress = (memberId: string) => {
    const points = getMemberPks(memberId);
    return getNextRankProgress(points);
  };

  const getMemberPillarBreakdown = (memberId: string) => {
    const breakdown = { C: 0, P: 0, B: 0, R: 0, S: 0 };
    mLogEntries
      .filter((entry) => entry.memberId === memberId && entry.status === 'verified')
      .forEach((entry) => {
        breakdown.C += entry.pillarPoints.C || 0;
        breakdown.P += entry.pillarPoints.P || 0;
        breakdown.B += entry.pillarPoints.B || 0;
        breakdown.R += entry.pillarPoints.R || 0;
        breakdown.S += entry.pillarPoints.S || 0;
      });
    return breakdown;
  };

  // Members Management with Dual Status Support
  const addMember = (memberData: Omit<User, 'id'>, initialPks: number = 0) => {
    const newId = `user_${Date.now()}`;
    const newUser: User = {
      ...memberData,
      id: newId,
      officerRole: (memberData.officerRole as OfficerRole) || 'None',
      projectHeadRoles: memberData.projectHeadRoles || [],
    };
    setAllUsers((prev) => [...prev, newUser]);

    if (initialPks > 0) {
      const baselineEntry: MLogEntry = {
        id: `mlog_init_${Date.now()}`,
        memberId: newId,
        memberName: newUser.fullName,
        memberAvatar: newUser.avatarUrl,
        eventTitle: 'Academic Year Initial Baseline / Starting PKS',
        date: new Date().toISOString().split('T')[0],
        roleOrAward: 'Starting Baseline Member Credit',
        codes: ['BASELINE_INIT'],
        pillarPoints: {
          C: Math.round(initialPks * 0.25),
          P: Math.round(initialPks * 0.35),
          B: Math.round(initialPks * 0.2),
          R: Math.round(initialPks * 0.1),
          S: Math.round(initialPks * 0.1),
        },
        totalPoints: initialPks,
        remarks: 'Initial starting PKS balance established at onboarding / app startup.',
        status: 'verified',
        verifiedBy: currentUser
          ? `${currentUser.fullName} (${currentUser.officerRole || currentUser.role})`
          : 'System Administrator',
        verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      };
      setMLogEntries((prev) => [baselineEntry, ...prev]);
    }

    showToast(
      `Account created for ${newUser.fullName} (@${newUser.username})${
        initialPks > 0 ? ` with +${initialPks} starting PKS baseline` : ''
      }`,
      'success'
    );
  };

  const updateMemberRole = (memberId: string, newRole: UserRole, isOfficer?: boolean) => {
    setAllUsers((prev) =>
      prev.map((user) => {
        if (user.id === memberId) {
          const officerStatus = isOfficer !== undefined ? isOfficer : isElevatedRole(newRole);
          const isOffRole = isElevatedRole(newRole);
          return {
            ...user,
            role: newRole,
            officerRole: isOffRole ? (newRole as OfficerRole) : user.officerRole || 'None',
            isOfficer: officerStatus,
          };
        }
        return user;
      })
    );
    showToast('Member role & permissions updated.', 'success');
  };

  const updateMemberDualRoles = (
    memberId: string,
    officerRole: OfficerRole,
    projectHeadRoles: string[] = [],
    isOfficer?: boolean
  ) => {
    setAllUsers((prev) =>
      prev.map((user) => {
        if (user.id === memberId) {
          const hasElevatedOfficer = officerRole !== 'None' && isElevatedRole(officerRole);
          const hasProjectHead = projectHeadRoles.length > 0;
          const officerStatus =
            isOfficer !== undefined
              ? isOfficer
              : hasElevatedOfficer || hasProjectHead || user.role === 'SuperAdmin';

          const primaryRole =
            officerRole !== 'None'
              ? officerRole
              : hasProjectHead
              ? `Project Head (${projectHeadRoles[0]})`
              : 'Member';

          return {
            ...user,
            officerRole,
            projectHeadRoles,
            role: primaryRole,
            isOfficer: officerStatus,
          };
        }
        return user;
      })
    );
    showToast('Dual status and leadership roles updated.', 'success');
  };

  const updateMemberProfile = (memberId: string, updates: Partial<User>) => {
    setAllUsers((prev) =>
      prev.map((user) => (user.id === memberId ? { ...user, ...updates } : user))
    );
    showToast('Profile information saved.', 'success');
  };

  // M.Log Ledger Operations with Automatic Rank Updates
  const addManualMLogEntry = (entry: Omit<MLogEntry, 'id' | 'submittedAt'>) => {
    const prevPoints = getMemberPks(entry.memberId);
    const prevRank = getRankTierForPks(prevPoints);
    const nextPoints = prevPoints + entry.totalPoints;
    const nextRank = getRankTierForPks(nextPoints);

    const newEntry: MLogEntry = {
      ...entry,
      id: `mlog_${Date.now()}`,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setMLogEntries((prev) => [newEntry, ...prev]);

    if (nextRank.id !== prevRank.id) {
      showToast(
        `🎉 Rank Promotion! ${entry.memberName} dynamically advanced to ${nextRank.name} (${nextPoints} PKS)!`,
        'success'
      );
    } else {
      showToast(`M.Log entry recorded: +${newEntry.totalPoints} PKS for ${newEntry.memberName}`, 'success');
    }
  };

  const submitMemberMLogRequest = (request: {
    eventTitle: string;
    roleOrAward: string;
    codes: string[];
    remarks: string;
    proofUrl?: string;
  }) => {
    if (!currentUser) return;

    const { total, breakdown } = calculatePksFromCodes(request.codes);
    const newEntry: MLogEntry = {
      id: `mlog_req_${Date.now()}`,
      memberId: currentUser.id,
      memberName: currentUser.fullName,
      memberAvatar: currentUser.avatarUrl,
      eventTitle: request.eventTitle,
      date: new Date().toISOString().split('T')[0],
      roleOrAward: request.roleOrAward,
      codes: request.codes,
      pillarPoints: breakdown,
      totalPoints: total,
      remarks: request.remarks,
      proofUrl: request.proofUrl,
      status: 'pending',
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setMLogEntries((prev) => [newEntry, ...prev]);
    showToast('Your M.Log entry has been queued for Officer Verification.', 'success');
  };

  const verifyMLogEntry = (entryId: string, status: 'verified' | 'rejected', notes?: string) => {
    if (!currentUser?.isOfficer) {
      showToast('Unauthorized: Only officers may verify entries.', 'error');
      return;
    }

    const targetEntry = mLogEntries.find((e) => e.id === entryId);
    if (targetEntry && status === 'verified') {
      const prevPoints = getMemberPks(targetEntry.memberId);
      const prevRank = getRankTierForPks(prevPoints);
      const nextPoints = prevPoints + targetEntry.totalPoints;
      const nextRank = getRankTierForPks(nextPoints);

      if (nextRank.id !== prevRank.id) {
        showToast(
          `🎉 Rank Promotion! ${targetEntry.memberName} dynamically promoted to ${nextRank.name} (${nextPoints} PKS)!`,
          'success'
        );
      }
    }

    setMLogEntries((prev) =>
      prev.map((entry) => {
        if (entry.id === entryId) {
          return {
            ...entry,
            status,
            verifiedBy: `${currentUser.fullName} (${currentUser.officerRole || currentUser.role})`,
            verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            remarks: notes ? `${entry.remarks} [Officer Note: ${notes}]` : entry.remarks,
          };
        }
        return entry;
      })
    );

    showToast(
      status === 'verified'
        ? 'Entry verified and PKS ledger credited.'
        : 'Entry marked as rejected.',
      status === 'verified' ? 'success' : 'info'
    );
  };

  const updateMLogEntry = (entryId: string, updates: Partial<MLogEntry>) => {
    if (!currentUser?.isOfficer) {
      showToast('Unauthorized: Only officers may modify M.Log entries.', 'error');
      return;
    }

    const targetEntry = mLogEntries.find((e) => e.id === entryId);
    if (!targetEntry) return;

    const prevPoints = getMemberPks(targetEntry.memberId);
    const prevRank = getRankTierForPks(prevPoints);

    let nextPillarPoints = updates.pillarPoints || targetEntry.pillarPoints;
    let nextTotalPoints = updates.totalPoints !== undefined ? updates.totalPoints : targetEntry.totalPoints;

    if (updates.codes && (!updates.pillarPoints || updates.totalPoints === undefined)) {
      const calc = calculatePksFromCodes(updates.codes);
      nextPillarPoints = calc.breakdown;
      nextTotalPoints = calc.total;
    }

    const updatedEntry: MLogEntry = {
      ...targetEntry,
      ...updates,
      pillarPoints: nextPillarPoints,
      totalPoints: nextTotalPoints,
    };

    const nextEntries = mLogEntries.map((e) => (e.id === entryId ? updatedEntry : e));
    setMLogEntries(nextEntries);

    // Compute updated total points and check for dynamic rank promotion/change
    const targetMember = allUsers.find((u) => u.id === targetEntry.memberId);
    const nextPoints = nextEntries
      .filter((e) => e.memberId === targetEntry.memberId && e.status === 'verified')
      .reduce((acc, curr) => acc + curr.totalPoints, 0);
    const nextRank = getRankTierForPks(nextPoints);

    if (nextRank.id !== prevRank.id) {
      showToast(
        `🎉 Dynamic Rank Updated! ${targetMember?.fullName || targetEntry.memberName} rank badge is now ${nextRank.name} (${nextPoints} PKS)!`,
        'success'
      );
    } else {
      showToast(`M.Log entry updated. Total: ${nextPoints} PKS.`, 'success');
    }
  };

  const deleteMLogEntry = (entryId: string) => {
    if (!currentUser?.isOfficer) {
      showToast('Unauthorized: Only officers may remove ledger entries.', 'error');
      return;
    }
    const targetEntry = mLogEntries.find((e) => e.id === entryId);
    if (!targetEntry) return;

    const prevPoints = getMemberPks(targetEntry.memberId);
    const prevRank = getRankTierForPks(prevPoints);

    setMLogEntries((prev) => prev.filter((e) => e.id !== entryId));

    if (targetEntry.status === 'verified') {
      const nextPoints = Math.max(0, prevPoints - targetEntry.totalPoints);
      const nextRank = getRankTierForPks(nextPoints);
      if (nextRank.id !== prevRank.id) {
        showToast(
          `Rank updated: ${targetEntry.memberName} recalculated to ${nextRank.name} (${nextPoints} PKS).`,
          'info'
        );
      } else {
        showToast(`Ledger entry removed. New total: ${nextPoints} PKS.`, 'info');
      }
    } else {
      showToast('Pending entry removed.', 'info');
    }
  };

  // Events & Contests
  const createEvent = (
    eventData: Omit<
      EventAssignment,
      'id' | 'assignedCrewIds' | 'volunteerCrewIds' | 'submittedEntriesCount'
    >
  ) => {
    const newEvent: EventAssignment = {
      ...eventData,
      id: `event_${Date.now()}`,
      assignedCrewIds: [],
      volunteerCrewIds: [],
      submittedEntriesCount: 0,
    };
    setEvents((prev) => [newEvent, ...prev]);
    showToast(`Published: ${newEvent.title}`, 'success');
  };

  const toggleVolunteer = (eventId: string) => {
    if (!currentUser) return;
    setEvents((prev) =>
      prev.map((ev) => {
        if (ev.id === eventId) {
          const isVolunteered = ev.volunteerCrewIds.includes(currentUser.id);
          const newVolunteers = isVolunteered
            ? ev.volunteerCrewIds.filter((id) => id !== currentUser.id)
            : [...ev.volunteerCrewIds, currentUser.id];

          showToast(
            isVolunteered ? 'Withdrawn from volunteer roster.' : 'You signed up as volunteer!',
            'info'
          );
          return { ...ev, volunteerCrewIds: newVolunteers };
        }
        return ev;
      })
    );
  };

  const assignCrew = (eventId: string, memberIds: string[]) => {
    setEvents((prev) =>
      prev.map((ev) => (ev.id === eventId ? { ...ev, assignedCrewIds: memberIds } : ev))
    );
    showToast('Crew assignments saved.', 'success');
  };

  const updateEventStatus = (eventId: string, status: 'upcoming' | 'ongoing' | 'completed') => {
    setEvents((prev) =>
      prev.map((ev) => (ev.id === eventId ? { ...ev, status } : ev))
    );
    showToast(`Event status updated to ${status}.`, 'info');
  };

  // Contest Submissions
  const submitToContest = (submission: {
    eventId: string;
    eventTitle: string;
    title: string;
    caption: string;
    imageUrl: string;
  }) => {
    if (!currentUser) return;

    const newSub: ContestSubmission = {
      id: `sub_${Date.now()}`,
      eventId: submission.eventId,
      eventTitle: submission.eventTitle,
      memberId: currentUser.id,
      memberName: currentUser.fullName,
      memberAvatar: currentUser.avatarUrl,
      title: submission.title,
      caption: submission.caption,
      imageUrl: submission.imageUrl,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
    };

    setContestSubmissions((prev) => [newSub, ...prev]);
    // increment event submission counter
    setEvents((prev) =>
      prev.map((e) =>
        e.id === submission.eventId
          ? { ...e, submittedEntriesCount: (e.submittedEntriesCount || 0) + 1 }
          : e
      )
    );

    // Also auto-queue a P5 (15 PKS) Participation M.Log request for submitting
    const { total, breakdown } = calculatePksFromCodes(['P5']);
    const mlogReq: MLogEntry = {
      id: `mlog_sub_${Date.now()}`,
      memberId: currentUser.id,
      memberName: currentUser.fullName,
      memberAvatar: currentUser.avatarUrl,
      eventTitle: `Contest Entry: ${submission.eventTitle}`,
      date: new Date().toISOString().split('T')[0],
      roleOrAward: `Contest Participant (${submission.title})`,
      codes: ['P5'],
      pillarPoints: breakdown,
      totalPoints: total,
      remarks: `Submitted entry "${submission.title}". Eligible for P5 School Contest Participant score.`,
      proofUrl: submission.imageUrl,
      status: 'pending',
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setMLogEntries((prev) => [mlogReq, ...prev]);

    showToast('Your contest entry has been submitted and queued for judging!', 'success');
  };

  const reviewSubmission = (
    submissionId: string,
    status: 'approved' | 'featured' | 'rejected',
    awardWon?: string,
    awardPksCodes?: string[]
  ) => {
    setContestSubmissions((prev) =>
      prev.map((sub) => {
        if (sub.id === submissionId) {
          return {
            ...sub,
            status,
            awardWon: awardWon || sub.awardWon,
          };
        }
        return sub;
      })
    );

    const sub = contestSubmissions.find((s) => s.id === submissionId);
    if (sub && awardPksCodes && awardPksCodes.length > 0 && status !== 'rejected') {
      const { total, breakdown } = calculatePksFromCodes(awardPksCodes);
      const awardEntry: MLogEntry = {
        id: `mlog_award_${Date.now()}`,
        memberId: sub.memberId,
        memberName: sub.memberName,
        memberAvatar: sub.memberAvatar,
        eventTitle: `Contest Award: ${sub.eventTitle}`,
        date: new Date().toISOString().split('T')[0],
        roleOrAward: awardWon || 'Contest Winner / Recognition',
        codes: awardPksCodes,
        pillarPoints: breakdown,
        totalPoints: total,
        remarks: `Recognized for entry "${sub.title}": ${awardWon || 'Contest Honor'}.`,
        proofUrl: sub.imageUrl,
        status: 'verified',
        verifiedBy: currentUser ? `${currentUser.fullName} (${currentUser.role})` : 'FPC Board',
        verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      };
      setMLogEntries((prev) => [awardEntry, ...prev]);
    }

    showToast(`Submission status updated to ${status}.`, 'success');
  };

  // Feed Posts
  const createFeedPost = (postData: Omit<FeedPost, 'id' | 'publishedAt' | 'applauseCount'>) => {
    const newPost: FeedPost = {
      ...postData,
      id: `feed_${Date.now()}`,
      publishedAt: 'Just now',
      applauseCount: 1,
    };
    setFeedPosts((prev) => [newPost, ...prev]);
    showToast('Feed announcement published.', 'success');
  };

  const applaudPost = (postId: string) => {
    setFeedPosts((prev) =>
      prev.map((post) =>
        post.id === postId ? { ...post, applauseCount: post.applauseCount + 1 } : post
      )
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        logout,
        switchUser,
        allUsers,
        activeTab,
        setActiveTab,
        systemSettings,
        updateSystemSettings,
        addMember,
        updateMemberRole,
        updateMemberDualRoles,
        updateMemberProfile,
        getMemberPks,
        getMemberRank,
        getMemberProgress,
        getMemberPillarBreakdown,
        mLogEntries,
        addManualMLogEntry,
        submitMemberMLogRequest,
        verifyMLogEntry,
        updateMLogEntry,
        deleteMLogEntry,
        events,
        createEvent,
        toggleVolunteer,
        assignCrew,
        updateEventStatus,
        contestSubmissions,
        submitToContest,
        reviewSubmission,
        feedPosts,
        createFeedPost,
        applaudPost,
        toasts,
        showToast,
        dismissToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
