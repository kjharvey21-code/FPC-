export type PillarCategory = 'C' | 'P' | 'B' | 'R' | 'S';

export interface PillarCodeDefinition {
  code: string;
  category: PillarCategory;
  categoryName: string;
  title: string;
  points: number;
  description: string;
}

export type OfficerRole =
  | 'SuperAdmin'
  | 'President'
  | 'VPIA'
  | 'VPCA'
  | 'Secretary'
  | 'Treasurer'
  | 'PEBU Head'
  | 'Creative Group Head'
  | 'Project Head'
  | 'None';

export type UserRole =
  | OfficerRole
  | 'Senior Creative'
  | 'Junior Creative'
  | 'Apprentice'
  | 'Member'
  | 'Applicant';

export interface CreativeTag {
  id: string;
  name: string;
  category: 'photography' | 'videography' | 'graphic_design' | 'editorial' | 'illustration' | 'technical';
}

export interface User {
  id: string;
  username: string;
  password?: string; // used for demo auth
  fullName: string;
  nickname: string;
  avatarUrl: string;
  // Dual Status Support:
  officerRole?: OfficerRole; // concurrent club officer role (e.g. President, VPIA, Head)
  projectHeadRoles?: string[]; // concurrent project head roles (e.g. "Intramurals 2026", "Foundation Day")
  role: string; // legacy or combined role descriptor
  isOfficer: boolean; // whether can access Admin tab
  creativeTags: string[];
  gradeSection: string;
  joinedDate: string;
  registrationDate?: string; // date member registered in the organization
  birthdate?: string; // birthdate of member
  batch?: string; // batch year/number e.g. "Batch 2026" / "Batch 8"
  bio: string;
}

export type RankTierId =
  | 'applicant'
  | 'member'
  | 'apprentice'
  | 'junior'
  | 'senior'
  | 'lead'
  | 'peak';

export interface RankTier {
  id: RankTierId;
  name: string;
  minPks: number;
  maxPks: number;
  badgeColor: string;
  bgGradient: string;
  textColor: string;
  borderColor: string;
  iconName: string;
  description: string;
  perks: string[];
}

export interface MLogEntry {
  id: string;
  memberId: string;
  memberName: string;
  memberAvatar: string;
  eventTitle: string;
  eventId?: string;
  date: string;
  roleOrAward: string;
  codes: string[]; // e.g. ["C2", "B2"]
  pillarPoints: {
    C: number;
    P: number;
    B: number;
    R: number;
    S: number;
  };
  totalPoints: number;
  remarks: string;
  proofUrl?: string;
  status: 'verified' | 'pending' | 'rejected';
  verifiedBy?: string;
  verifiedAt?: string;
  submittedAt: string;
}

export type EventType = 'shoot' | 'contest' | 'workshop' | 'meeting' | 'coverage';

export interface EventAssignment {
  id: string;
  title: string;
  type: EventType;
  date: string;
  time: string;
  location: string;
  description: string;
  bannerUrl: string;
  assignedCrewIds: string[];
  volunteerCrewIds: string[];
  maxCrew?: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  isContest?: boolean;
  contestDeadline?: string;
  contestPrize?: string;
  submittedEntriesCount?: number;
  eligibleCodes: string[];
}

export interface ContestSubmission {
  id: string;
  eventId: string;
  eventTitle: string;
  memberId: string;
  memberName: string;
  memberAvatar: string;
  title: string;
  caption: string;
  imageUrl: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'featured' | 'rejected';
  awardWon?: string;
}

export interface FeedPost {
  id: string;
  title: string;
  content: string;
  category: 'announcement' | 'contest_winner' | 'showcase' | 'behind_the_scenes';
  authorName: string;
  authorRole: string;
  authorAvatar: string;
  publishedAt: string;
  imageUrl?: string;
  tags: string[];
  applauseCount: number;
  featuredPksWinner?: {
    memberName: string;
    pointsWon: number;
    rankBadge: string;
  };
}

export interface SystemSettings {
  appName: string;
  schoolName: string;
  orgTagline: string;
  logoUrl: string;
  academicYear: string;
  announcementBanner: string;
  bannerActive: boolean;
  mLogSubmissionOpen: boolean;
}
