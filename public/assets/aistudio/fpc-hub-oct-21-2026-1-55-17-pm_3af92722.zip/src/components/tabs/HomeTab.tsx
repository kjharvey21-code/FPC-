import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EventAssignment } from '../../types';
import { getRankTierForPks, getNextRankProgress } from '../../data/pksFramework';
import {
  Calendar,
  Clock,
  MapPin,
  ChevronRight,
  Camera,
  Users,
  Award,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Megaphone,
} from 'lucide-react';
import { EventDetailsModal } from '../modals/EventDetailsModal';
import { SubmitContestModal } from '../modals/SubmitContestModal';

export const HomeTab: React.FC = () => {
  const {
    currentUser,
    events,
    getMemberPks,
    getMemberRank,
    getMemberProgress,
    toggleVolunteer,
    systemSettings,
    setActiveTab,
  } = useApp();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'shoot' | 'contest' | 'workshop'>('all');
  const [activeEventModal, setActiveEventModal] = useState<EventAssignment | null>(null);
  const [contestSubmitEvent, setContestSubmitEvent] = useState<EventAssignment | null>(null);

  if (!currentUser) return null;

  const totalPks = getMemberPks(currentUser.id);
  const rank = getMemberRank(currentUser.id);
  const progress = getMemberProgress(currentUser.id);

  const filteredEvents = events.filter((ev) => {
    if (selectedFilter === 'all') return true;
    return ev.type === selectedFilter;
  });

  // Segregate into "Today / In-Progress" and "Upcoming"
  const todayEvents = filteredEvents.filter((ev) => ev.status === 'ongoing');
  const upcomingEvents = filteredEvents.filter((ev) => ev.status === 'upcoming');

  const renderEventCard = (ev: EventAssignment) => {
    const isAssigned = ev.assignedCrewIds.includes(currentUser.id);
    const isVolunteered = ev.volunteerCrewIds.includes(currentUser.id);

    return (
      <div
        key={ev.id}
        className="group relative bg-slate-900/90 border border-slate-800/90 hover:border-slate-700 rounded-2xl sm:rounded-3xl overflow-hidden transition-all duration-200 hover:shadow-xl hover:shadow-black/40 flex flex-col sm:flex-row"
      >
        {/* Thumbnail media */}
        <div className="relative w-full sm:w-44 md:w-52 h-28 sm:h-auto shrink-0 bg-slate-950 overflow-hidden">
          <img
            src={ev.bannerUrl}
            alt={ev.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-slate-900/90 via-transparent to-transparent" />

          {/* Type tag */}
          <div className="absolute top-2.5 left-2.5 sm:top-3 sm:left-3">
            <span className="text-[9px] sm:text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md sm:rounded-lg bg-slate-950/80 text-amber-400 border border-amber-500/30 backdrop-blur-xs">
              {ev.type}
            </span>
          </div>

          {/* Quick status badge if user is involved */}
          {(isAssigned || isVolunteered) && (
            <div className="absolute bottom-2 left-2 sm:hidden">
              <span
                className={`text-[9px] font-semibold px-2 py-0.5 rounded ${
                  isAssigned
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-emerald-500 text-slate-950'
                }`}
              >
                {isAssigned ? 'Assigned' : 'Volunteered'}
              </span>
            </div>
          )}
        </div>

        {/* Card Body */}
        <div className="p-3 sm:p-5 flex-1 flex flex-col justify-between">
          <div>
            {/* Unboxed metadata row with typographic separators */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs text-slate-400 font-medium mb-1 sm:mb-1.5">
              <span className="flex items-center gap-1 text-slate-300">
                <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-400" />
                {ev.date}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-500" />
                {ev.time}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 truncate max-w-[140px] sm:max-w-[180px]">
                <MapPin className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-500" />
                {ev.location}
              </span>
            </div>

            <h3
              onClick={() => setActiveEventModal(ev)}
              className="text-sm sm:text-base md:text-lg font-bold text-white hover:text-amber-300 transition-colors cursor-pointer leading-snug line-clamp-2"
            >
              {ev.title}
            </h3>

            <p className="text-[11px] sm:text-xs text-slate-400 mt-1 sm:mt-2 line-clamp-1 sm:line-clamp-2 leading-relaxed">
              {ev.description}
            </p>
          </div>

          {/* Bottom Card Controls & Reclub Status Badges */}
          <div className="mt-2.5 sm:mt-4 pt-2 sm:pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
            {/* Left status markers */}
            <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs">
              {isAssigned ? (
                <span className="font-semibold text-amber-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Assigned Crew
                </span>
              ) : isVolunteered ? (
                <span className="font-semibold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Volunteered
                </span>
              ) : ev.isContest ? (
                <span className="text-rose-300 font-medium flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-rose-400" />
                  {ev.submittedEntriesCount || 0} entries
                </span>
              ) : (
                <span className="text-slate-400 flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {ev.assignedCrewIds.length} assigned
                </span>
              )}
            </div>

            {/* Right Action buttons */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {ev.isContest ? (
                <button
                  type="button"
                  onClick={() => setContestSubmitEvent(ev)}
                  className="px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-lg sm:rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-[11px] sm:text-xs transition-colors flex items-center gap-1 cursor-pointer shadow-sm active:scale-95"
                >
                  <Camera className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span>Submit Entry</span>
                </button>
              ) : !isAssigned ? (
                <button
                  type="button"
                  onClick={() => toggleVolunteer(ev.id)}
                  className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-medium transition-colors cursor-pointer border ${
                    isVolunteered
                      ? 'border-rose-800/60 text-rose-300 bg-rose-950/40 hover:bg-rose-900/60'
                      : 'border-slate-700 text-slate-200 bg-slate-800 hover:bg-slate-700'
                  }`}
                >
                  {isVolunteered ? 'Withdraw' : 'Volunteer'}
                </button>
              ) : null}

              <button
                type="button"
                onClick={() => setActiveEventModal(ev)}
                className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] sm:text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>Details</span>
                <ChevronRight className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-200">
      {/* Reclub-Inspired Minimalist Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          {/* Left Greeting & Nickname */}
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.fullName}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500/40"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-950 flex items-center justify-center border border-amber-500/40 text-amber-400 text-[10px] font-bold">
                ✓
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400 font-medium">Welcome back,</div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Hi, {currentUser.nickname}!
              </h1>
              <div className="flex flex-wrap items-center gap-1.5 text-xs text-amber-400/90 font-medium mt-1">
                <span className="font-semibold">{rank.name}</span>
                {currentUser.officerRole && currentUser.officerRole !== 'None' && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-200">{currentUser.officerRole}</span>
                  </>
                )}
                {currentUser.projectHeadRoles && currentUser.projectHeadRoles.length > 0 && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-amber-300">Head: {currentUser.projectHeadRoles.join(', ')}</span>
                  </>
                )}
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-slate-400">{currentUser.gradeSection}</span>
              </div>
            </div>
          </div>

          {/* Right Quick Status & Numbers (PKS & Rank Badge) */}
          <div className="flex items-center gap-3 bg-slate-950/70 border border-slate-800/80 p-3 rounded-2xl">
            <div className="px-3 border-r border-slate-800 text-left">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Total PKS
              </div>
              <div className="text-xl sm:text-2xl font-black font-mono text-amber-400 tabular-nums">
                {totalPks}
              </div>
            </div>

            <div className="px-2 text-left">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Rank Badge
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${rank.badgeColor}`}>
                  {rank.name}
                </span>
              </div>
              {progress.nextTier && (
                <div className="text-[10px] text-slate-400 mt-1 font-mono">
                  {progress.pointsRemaining} pts to {progress.nextTier.name}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Next Tier Micro Progress Bar */}
        {progress.nextTier && (
          <div className="mt-4 pt-4 border-t border-slate-800/60">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5 font-medium">
              <span>Promotion Review: {rank.name}</span>
              <span className="font-mono text-amber-400">{progress.progressPercent}%</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-500"
                style={{ width: `${progress.progressPercent}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Global Announcement Banner (if active) */}
      {systemSettings.bannerActive && systemSettings.announcementBanner && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs sm:text-sm flex items-start gap-3 shadow-lg shadow-amber-500/5">
          <Megaphone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold text-amber-300">Official Announcement: </span>
            <span>{systemSettings.announcementBanner}</span>
          </div>
        </div>
      )}

      {/* Interactive Filter Controls */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5 p-2 bg-slate-900 border border-slate-800 rounded-2xl shadow-md">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`min-h-[44px] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'all'
                ? 'bg-amber-500 text-slate-950 shadow-md scale-[1.02]'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            All Events ({events.length})
          </button>
          <button
            onClick={() => setSelectedFilter('shoot')}
            className={`min-h-[44px] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'shoot'
                ? 'bg-amber-500 text-slate-950 shadow-md scale-[1.02]'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Shoots & Coverage
          </button>
          <button
            onClick={() => setSelectedFilter('contest')}
            className={`min-h-[44px] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'contest'
                ? 'bg-amber-500 text-slate-950 shadow-md scale-[1.02]'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Contests
          </button>
          <button
            onClick={() => setSelectedFilter('workshop')}
            className={`min-h-[44px] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'workshop'
                ? 'bg-amber-500 text-slate-950 shadow-md scale-[1.02]'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Workshops
          </button>
        </div>

        <button
          onClick={() => setActiveTab('profile')}
          className="text-xs text-amber-400 hover:text-amber-300 font-medium whitespace-nowrap hidden sm:flex items-center gap-1 cursor-pointer"
        >
          <span>Open Personal M.Log</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Section 1: In-Progress / Today */}
      {todayEvents.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span>Today & In-Progress</span>
            </h2>
            <span className="text-xs text-slate-500 font-mono">Live Call Sheet</span>
          </div>

          <div className="space-y-2.5 sm:space-y-3">{todayEvents.map(renderEventCard)}</div>
        </section>
      )}

      {/* Section 2: Upcoming Assignments & Contests */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Upcoming Production & Contests</h2>
          <span className="text-xs text-slate-400 font-mono">
            {upcomingEvents.length} scheduled
          </span>
        </div>

        {upcomingEvents.length === 0 ? (
          <div className="text-center py-10 bg-slate-900/50 rounded-3xl border border-slate-800 text-slate-400 text-xs">
            No upcoming events matching this filter.
          </div>
        ) : (
          <div className="space-y-3">{upcomingEvents.map(renderEventCard)}</div>
        )}
      </section>

      {/* Modals */}
      {activeEventModal && (
        <EventDetailsModal
          event={activeEventModal}
          onClose={() => setActiveEventModal(null)}
          onOpenSubmitEntry={() => setContestSubmitEvent(activeEventModal)}
        />
      )}

      {contestSubmitEvent && (
        <SubmitContestModal
          event={contestSubmitEvent}
          onClose={() => setContestSubmitEvent(null)}
        />
      )}
    </div>
  );
};
