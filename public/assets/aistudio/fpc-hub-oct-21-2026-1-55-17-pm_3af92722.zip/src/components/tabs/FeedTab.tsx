import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FeedPost } from '../../types';
import {
  Heart,
  MessageCircle,
  Share2,
  Sparkles,
  Plus,
  X,
  Award,
  Filter,
  Camera,
  Maximize2,
} from 'lucide-react';

export const FeedTab: React.FC = () => {
  const { feedPosts, applaudPost, currentUser, createFeedPost } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New post form state
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postCategory, setPostCategory] = useState<FeedPost['category']>('announcement');
  const [postImage, setPostImage] = useState('/src/assets/images/fpc_contest_streetphoto_1792558823968.jpg');
  const [postTags, setPostTags] = useState('Spotlight, Photography');

  const filteredPosts = feedPosts.filter((post) => {
    if (activeCategory === 'all') return true;
    return post.category === activeCategory;
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !postTitle.trim() || !postContent.trim()) return;

    createFeedPost({
      title: postTitle.trim(),
      content: postContent.trim(),
      category: postCategory,
      authorName: currentUser.fullName,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      imageUrl: postImage,
      tags: postTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
    });

    setPostTitle('');
    setPostContent('');
    setShowCreateModal(false);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-200">
      {/* Feed Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl backdrop-blur-md">
        <div>
          <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
            Official Community Wire
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-0.5">
            FPC Creative Feed
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Club announcements, contest honors, student media showcases, and behind-the-scenes logs.
          </p>
        </div>

        {currentUser?.isOfficer && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="self-start sm:self-center px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Publish Post</span>
          </button>
        )}
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All Posts' },
          { id: 'announcement', label: 'Announcements' },
          { id: 'contest_winner', label: 'Contest Winners' },
          { id: 'showcase', label: 'Creative Showcase' },
          { id: 'behind_the_scenes', label: 'Behind the Scenes' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveCategory(tab.id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-xl transition-colors whitespace-nowrap cursor-pointer border ${
              activeCategory === tab.id
                ? 'bg-amber-500 text-slate-950 font-semibold border-amber-400 shadow-sm'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Posts List */}
      <div className="space-y-5">
        {filteredPosts.map((post) => (
          <article
            key={post.id}
            className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl"
          >
            {/* Post Author Bar */}
            <div className="p-4 sm:p-5 flex items-center justify-between border-b border-slate-800/80">
              <div className="flex items-center gap-3">
                <img
                  src={post.authorAvatar}
                  alt={post.authorName}
                  className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="text-sm font-semibold text-white leading-none">
                    {post.authorName}
                  </h3>
                  {/* Unboxed metadata line with typographic separator */}
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1">
                    <span className="text-amber-400/90 font-medium">{post.authorRole}</span>
                    <span aria-hidden="true">·</span>
                    <span>{post.publishedAt}</span>
                  </div>
                </div>
              </div>

              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                {post.category.replace(/_/g, ' ')}
              </span>
            </div>

            {/* Post Media (if provided) */}
            {post.imageUrl && (
              <div
                className="relative aspect-video sm:aspect-[21/9] w-full bg-slate-950 overflow-hidden cursor-pointer group"
                onClick={() => setLightboxImage(post.imageUrl || null)}
              >
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="p-2 rounded-full bg-black/70 text-white backdrop-blur-xs">
                    <Maximize2 className="w-5 h-5" />
                  </span>
                </div>
              </div>
            )}

            {/* Post Content */}
            <div className="p-5 sm:p-6 space-y-3">
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-snug">
                {post.title}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {post.content}
              </p>

              {/* Contest Spotlight Badge (if applicable) */}
              {post.featuredPksWinner && (
                <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 via-purple-500/10 to-transparent border border-amber-500/30 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-400 shrink-0" />
                    <div>
                      <span className="text-slate-300">Winner Credited: </span>
                      <strong className="text-white">{post.featuredPksWinner.memberName}</strong>
                      <span className="text-slate-400 text-[11px]"> ({post.featuredPksWinner.rankBadge})</span>
                    </div>
                  </div>
                  <div className="font-mono font-bold text-amber-400">
                    +{post.featuredPksWinner.pointsWon} PKS
                  </div>
                </div>
              )}

              {/* Tags (Unboxed text with dots) */}
              {post.tags && post.tags.length > 0 && (
                <div className="pt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  {post.tags.map((tag, idx) => (
                    <React.Fragment key={tag}>
                      <span>#{tag}</span>
                      {idx < post.tags.length - 1 && <span aria-hidden="true">·</span>}
                    </React.Fragment>
                  ))}
                </div>
              )}

              {/* Interactive Engagement Bar */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => applaudPost(post.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-amber-400 hover:text-amber-300 font-medium transition-colors cursor-pointer active:scale-95"
                >
                  <Heart className="w-4 h-4 fill-amber-400/20" />
                  <span>Applaud ({post.applauseCount})</span>
                </button>

                <div className="flex items-center gap-3">
                  <span className="text-slate-500 text-[11px]">San Jose NHS FPC Press</span>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center">
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute -top-12 right-0 p-2 text-slate-300 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={lightboxImage}
              alt="Enlarged view"
              className="max-h-[85vh] w-auto max-w-full rounded-2xl object-contain shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}

      {/* Create Post Modal for Officers */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Create Official Feed Post</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={postCategory}
                  onChange={(e) => setPostCategory(e.target.value as FeedPost['category'])}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                >
                  <option value="announcement">Announcement</option>
                  <option value="contest_winner">Contest Winner</option>
                  <option value="showcase">Showcase</option>
                  <option value="behind_the_scenes">Behind the Scenes</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Post Title
                </label>
                <input
                  type="text"
                  required
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  placeholder="e.g. Coverage Wrap: Division Press Conference"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Content / Article Body
                </label>
                <textarea
                  rows={4}
                  required
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  placeholder="Write the announcement or event recap..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Cover Photo / Image URL
                </label>
                <input
                  type="text"
                  value={postImage}
                  onChange={(e) => setPostImage(e.target.value)}
                  placeholder="/src/assets/images/..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tags (Comma separated)
                </label>
                <input
                  type="text"
                  value={postTags}
                  onChange={(e) => setPostTags(e.target.value)}
                  placeholder="e.g. Intramurals, Photography, San Jose NHS"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs shadow-md"
                >
                  Publish to Feed
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
