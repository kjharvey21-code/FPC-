import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  getRankTierForPks,
  getNextRankProgress,
  RANK_TIERS,
  PILLAR_CODES,
} from '../../data/pksFramework';
import {
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  Sparkles,
  FileCheck,
  AlertCircle,
  Plus,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Tag,
  Shield,
  Layers,
  X,
} from 'lucide-react';
import { RequestMLogModal } from '../modals/RequestMLogModal';

export const ProfileTab: React.FC = () => {
  const {
    currentUser,
    getMemberPks,
    getMemberRank,
    getMemberProgress,
    getMemberPillarBreakdown,
    mLogEntries,
  } = useApp();
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [selectedProofUrl, setSelectedProofUrl] = useState<string | null>(null);
  const [activeLedgerFilter, setActiveLedgerFilter] = useState<'all' | 'verified' | 'pending'>('all');

  if (!currentUser) return null;

  const totalPks = getMemberPks(currentUser.id);
  const currentTier = getMemberRank(currentUser.id);
  const progress = getMemberProgress(currentUser.id);
  const pillarBreakdown = getMemberPillarBreakdown(currentUser.id);

  // User's personal ledger entries
  const userEntries = mLogEntries.filter((entry) => entry.memberId === currentUser.id);
  const filteredEntries = userEntries.filter((entry) => {
    if (activeLedgerFilter === 'all') return true;
    return entry.status === activeLedgerFilter;
  });

  const pillarCards = [
    {
      code: 'C',
      name: 'Creative Outputs',
      points: pillarBreakdown.C,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
      borderColor: 'border-amber-500/30',
      desc: 'Assets, Posters, Reels & Masterpieces (C1-C4)',
    },
    {
      code: 'P',
      name: 'Participation',
      points: pillarBreakdown.P,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/10',
      borderColor: 'border-sky-500/30',
      desc: 'Meetings, Workshops, Shoot Crew & Contests (P1-P9)',
    },
    {
      code: 'B',
      name: 'Responsibility & Lead',
      points: pillarBreakdown.B,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10',
      borderColor: 'border-indigo-500/30',
      desc: 'Mentorship, Shoot Direction & Executive (B1-B4)',
    },
    {
      code: 'R',
      name: 'Recognition & Awards',
      points: pillarBreakdown.R,
      color: 'text-rose-400',
      bgColor: 'bg-rose-500/10',
      borderColor: 'border-rose-500/30',
      desc: 'School, City, Regional & National Honors (R1-R5)',
    },
    {
      code: 'S',
      name: 'Special Distinction',
      points: pillarBreakdown.S,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
      desc: 'Skill Milestones, Streaks & Trust Roles (S1-S6)',
    },
  ];

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-200">
      {/* Member Profile Header Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Member Identity & Tags */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="relative">
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.fullName}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover border-2 border-amber-500/40 shadow-xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-2 -right-1 px-2 py-0.5 rounded-md bg-slate-950 border border-amber-500/50 text-[10px] font-bold text-amber-400">
                {currentTier.name}
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {currentUser.fullName}
                </h1>
                <span className="text-xs text-slate-400 font-medium">({currentUser.nickname})</span>
              </div>

              {/* Dual Status Support: Creative Rank + Concurrent Leadership Post */}
              <div className="flex flex-wrap items-center gap-2 pt-0.5">
                <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${currentTier.badgeColor} ${currentTier.borderColor}`}>
                  Rank: {currentTier.name}
                </span>

                {currentUser.officerRole && currentUser.officerRole !== 'None' && (
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-300">
                    Officer: {currentUser.officerRole}
                  </span>
                )}

                {currentUser.projectHeadRoles && currentUser.projectHeadRoles.length > 0 && (
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-purple-500/15 border border-purple-500/40 text-purple-300">
                    Project Head: {currentUser.projectHeadRoles.join(', ')}
                  </span>
                )}
              </div>

              {/* Unboxed metadata line with typographic separators */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-medium pt-1">
                <span>{currentUser.gradeSection}</span>
                <span aria-hidden="true">·</span>
                <span>Joined {currentUser.joinedDate}</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-mono">Dynamic M.Log Sync Active</span>
              </div>

              <p className="text-xs text-slate-300 max-w-xl leading-relaxed pt-1">
                {currentUser.bio}
              </p>

              {/* Creative Tags */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
                {currentUser.creativeTags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[11px] px-2.5 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Quick PKS Total Badge */}
          <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center p-4 bg-slate-950/80 border border-slate-800 rounded-2xl shrink-0">
            <div className="text-left sm:text-right">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Accumulated PKS
              </div>
              <div className="text-3xl font-black font-mono text-amber-400 tabular-nums">
                {totalPks}
              </div>
            </div>
            <div className="text-left sm:text-right text-[11px] text-slate-400 mt-1">
              Tier: <strong className="text-white">{currentTier.name}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Official 4-Pillar Points Distribution */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Official 4-Pillar PKS Points Distribution</span>
            </h2>
            <p className="text-xs text-slate-400">
              Verified points balance categorized by creative work, leadership, and honors.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {pillarCards.map((p) => {
            const percent = totalPks > 0 ? Math.round((p.points / totalPks) * 100) : 0;
            return (
              <div
                key={p.code}
                className={`p-4 rounded-2xl bg-slate-900/90 border ${p.borderColor} flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                      Pillar {p.code}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">{percent}%</span>
                  </div>
                  <h3 className="text-sm font-semibold text-white mt-1.5">{p.name}</h3>
                  <p className="text-[10px] text-slate-400 mt-1 leading-snug">{p.desc}</p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-baseline justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Points</span>
                  <span className={`text-xl font-bold font-mono tabular-nums ${p.color}`}>
                    {p.points}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Rank Progression & Certification Checklist */}
      <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
              Merit & Rank Progression
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2 mt-0.5">
              <Award className="w-5 h-5 text-amber-400" />
              <span>Current Status: {currentTier.name} ({currentTier.minPks} – {currentTier.maxPks} PKS)</span>
            </h2>
          </div>

          {progress.nextTier && (
            <div className="text-xs text-right">
              <div className="text-slate-400 font-medium">
                Next Rank: <strong className="text-amber-300">{progress.nextTier.name}</strong>
              </div>
              <div className="text-amber-400 font-mono font-semibold">
                Needs {progress.pointsRemaining} more PKS
              </div>
            </div>
          )}
        </div>

        {/* Progress Bar */}
        {progress.nextTier && (
          <div className="space-y-1.5">
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-400 rounded-full transition-all duration-700"
                style={{ width: `${progress.progressPercent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>{currentTier.minPks} PKS ({currentTier.name})</span>
              <span>{progress.progressPercent}% to Promotion</span>
              <span>{progress.nextTier.minPks} PKS ({progress.nextTier.name})</span>
            </div>
          </div>
        )}

        {/* Interactive Rank Tiers Journey Grid */}
        <div className="space-y-2 pt-2">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            FPC Rank Tier Checklist
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2">
            {RANK_TIERS.map((tier, idx) => {
              const isAchieved = totalPks >= tier.minPks;
              const isCurrent = currentTier.id === tier.id;

              return (
                <div
                  key={tier.id}
                  className={`p-3 rounded-2xl border text-xs flex flex-col justify-between transition-all ${
                    isCurrent
                      ? 'bg-amber-500/15 border-amber-400 shadow-lg shadow-amber-500/10'
                      : isAchieved
                      ? 'bg-slate-950/80 border-slate-700 text-slate-300'
                      : 'bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[10px] text-slate-400">Tier {idx + 1}</span>
                      {isAchieved && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}
                    </div>
                    <div className="font-bold text-white text-xs">{tier.name}</div>
                    <div className="text-[10px] font-mono text-amber-400 mt-0.5">
                      {tier.minPks}+ PKS
                    </div>
                  </div>

                  <div className="mt-2 pt-1 border-t border-slate-800/60 text-[9px] text-slate-400 line-clamp-2">
                    {tier.perks[0]}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Personal M.Log Ledger */}
      <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-400" />
              <span>Personal M.Log Ledger</span>
            </h2>
            <p className="text-xs text-slate-400">
              Verified record of your completed shoots, creative outputs, and awards.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-xl text-xs">
              <button
                onClick={() => setActiveLedgerFilter('all')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeLedgerFilter === 'all'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All ({userEntries.length})
              </button>
              <button
                onClick={() => setActiveLedgerFilter('verified')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeLedgerFilter === 'verified'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Verified
              </button>
              <button
                onClick={() => setActiveLedgerFilter('pending')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeLedgerFilter === 'pending'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Pending
              </button>
            </div>

            {/* Request M.Log button */}
            <button
              onClick={() => setShowRequestModal(true)}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Request Verification</span>
            </button>
          </div>
        </div>

        {/* Ledger Table / List */}
        {filteredEntries.length === 0 ? (
          <div className="text-center py-10 bg-slate-950/40 rounded-2xl border border-slate-800 text-slate-400 text-xs">
            No ledger entries found for this filter. Click &ldquo;Request Verification&rdquo; to submit your latest creative activity.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3">Event / Creative Project</th>
                  <th className="py-3 px-3">Role / Distinction</th>
                  <th className="py-3 px-3">PKS Codes</th>
                  <th className="py-3 px-3">Remarks / Verification</th>
                  <th className="py-3 px-3 text-right">Points</th>
                  <th className="py-3 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {filteredEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-3 whitespace-nowrap text-slate-400 font-mono">
                      {entry.date}
                    </td>

                    <td className="py-3.5 px-3 text-white max-w-xs">
                      <div className="font-semibold text-sm text-slate-100">{entry.eventTitle}</div>
                      {entry.proofUrl && (
                        <button
                          type="button"
                          onClick={() => setSelectedProofUrl(entry.proofUrl || null)}
                          className="text-[11px] text-amber-400 hover:underline flex items-center gap-1 mt-0.5 cursor-pointer"
                        >
                          <span>View Proof File</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </button>
                      )}
                    </td>

                    <td className="py-3.5 px-3 text-slate-300">
                      {entry.roleOrAward}
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex flex-wrap gap-1">
                        {entry.codes.map((code) => (
                          <span
                            key={code}
                            className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-amber-300"
                          >
                            {code}
                          </span>
                        ))}
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-slate-400 max-w-sm">
                      <div className="line-clamp-2">{entry.remarks}</div>
                      {entry.verifiedBy && (
                        <div className="text-[10px] text-emerald-400/90 font-mono mt-0.5">
                          ✓ Verified by {entry.verifiedBy}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono font-bold text-sm text-amber-400 tabular-nums whitespace-nowrap">
                      +{entry.totalPoints}
                    </td>

                    <td className="py-3.5 px-3 text-right whitespace-nowrap">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                          entry.status === 'verified'
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                            : entry.status === 'pending'
                            ? 'bg-amber-950/80 text-amber-300 border border-amber-700/50'
                            : 'bg-rose-950/80 text-rose-300 border border-rose-700/50'
                        }`}
                      >
                        {entry.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Proof Lightbox Modal */}
      {selectedProofUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setSelectedProofUrl(null)}
        >
          <div className="relative max-w-3xl w-full flex flex-col items-center">
            <button
              onClick={() => setSelectedProofUrl(null)}
              className="absolute -top-12 right-0 p-2 text-slate-300 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={selectedProofUrl}
              alt="M.Log Proof"
              className="max-h-[80vh] w-auto max-w-full rounded-2xl object-contain shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}

      {/* Request M.Log Modal */}
      {showRequestModal && (
        <RequestMLogModal onClose={() => setShowRequestModal(false)} />
      )}
    </div>
  );
};
