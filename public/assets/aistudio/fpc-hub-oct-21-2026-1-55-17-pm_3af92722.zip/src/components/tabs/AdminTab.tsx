import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  PILLAR_CODES,
  validatePksSelection,
  calculatePksFromCodes,
  isElevatedRole,
  getRankTierForPks,
} from '../../data/pksFramework';
import { UserRole, OfficerRole, EventType, MLogEntry, User } from '../../types';
import { compressImageFile } from '../../utils/imageUtils';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  FileText,
  CalendarPlus,
  Users,
  Settings,
  AlertCircle,
  Upload,
  Plus,
  ExternalLink,
  Sparkles,
  Award,
  Layers,
  Search,
  Edit3,
  Trash2,
  Tag,
  Briefcase,
  UserCheck,
  ChevronRight,
  X,
  Zap,
} from 'lucide-react';

export const AdminTab: React.FC = () => {
  const {
    currentUser,
    allUsers,
    mLogEntries,
    verifyMLogEntry,
    updateMLogEntry,
    deleteMLogEntry,
    addManualMLogEntry,
    createEvent,
    addMember,
    updateMemberDualRoles,
    systemSettings,
    updateSystemSettings,
    getMemberPks,
    getMemberRank,
  } = useApp();

  const [adminSection, setAdminSection] = useState<
    'queue' | 'manual_mlog' | 'ledger_audit' | 'create_event' | 'members' | 'superadmin'
  >('queue');

  // Pending M.Log entries
  const pendingEntries = mLogEntries.filter((e) => e.status === 'pending');

  // Manual M.Log Tool state
  const [selectedMemberId, setSelectedMemberId] = useState(allUsers[0]?.id || '');
  const [manualEventTitle, setManualEventTitle] = useState('');
  const [manualRole, setManualRole] = useState('Courtside Coverage Crew');
  const [manualCodes, setManualCodes] = useState<string[]>(['C2', 'B2']);
  const [manualRemarks, setManualRemarks] = useState('Official coverage assignment completed.');

  // Direct Starting / Baseline PKS mode
  const [manualMode, setManualMode] = useState<'baseline' | 'codes'>('baseline');
  const [directPksAmount, setDirectPksAmount] = useState<number>(50);
  const [directReasonTitle, setDirectReasonTitle] = useState<string>('Academic Year Initial Starting PKS');
  const [directRoleTitle, setDirectRoleTitle] = useState<string>('Member Baseline Credit');

  // Member Directory Direct Credit Modal
  const [creditingMember, setCreditingMember] = useState<User | null>(null);
  const [modalCreditAmount, setModalCreditAmount] = useState<number>(50);
  const [modalCreditReason, setModalCreditReason] = useState<string>('Academic Year Initial Starting PKS');
  const [modalCreditRole, setModalCreditRole] = useState<string>('Starting Member Credit');
  const [modalCreditNotes, setModalCreditNotes] = useState<string>('Initial onboarding starting PKS baseline credited.');

  // Create Event state
  const [eventTitle, setEventTitle] = useState('');
  const [eventType, setEventType] = useState<EventType>('shoot');
  const [eventDate, setEventDate] = useState('2026-10-30');
  const [eventTime, setEventTime] = useState('8:00 AM – 3:00 PM');
  const [eventLocation, setEventLocation] = useState('SJNHS Audio-Visual Center');
  const [eventDescription, setEventDescription] = useState('');
  const [eventBanner, setEventBanner] = useState('/src/assets/images/fpc_workshop_cover_1792558823447.jpg');
  const [isContest, setIsContest] = useState(false);
  const [contestPrize, setContestPrize] = useState('1st: +40 PKS (R1) · 2nd: +25 PKS');
  const [eligibleCodes, setEligibleCodes] = useState<string[]>(['C2', 'P4', 'B2', 'S2']);

  const toggleEligibleCode = (code: string) => {
    setEligibleCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  // Create Member state
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('fpc2026');
  const [newFullName, setNewFullName] = useState('');
  const [newNickname, setNewNickname] = useState('');
  const [newOfficerRole, setNewOfficerRole] = useState<OfficerRole>('None');
  const [newProjectHeadInput, setNewProjectHeadInput] = useState('');
  const [newGrade, setNewGrade] = useState('Grade 11 ICT-A');
  const [newTags, setNewTags] = useState('Photographer, Editor');
  const [newRegistrationDate, setNewRegistrationDate] = useState(new Date().toISOString().split('T')[0]);
  const [newBirthdate, setNewBirthdate] = useState('2009-01-01');
  const [newBatch, setNewBatch] = useState('Batch 2026');
  const [newInitialPks, setNewInitialPks] = useState<number>(0);

  // SuperAdmin Settings state
  const [appNameInput, setAppNameInput] = useState(systemSettings.appName);
  const [schoolNameInput, setSchoolNameInput] = useState(systemSettings.schoolName);
  const [taglineInput, setTaglineInput] = useState(systemSettings.orgTagline);
  const [logoInput, setLogoInput] = useState(systemSettings.logoUrl);
  const [academicYearInput, setAcademicYearInput] = useState(systemSettings.academicYear);
  const [bannerInput, setBannerInput] = useState(systemSettings.announcementBanner);
  const [bannerActiveInput, setBannerActiveInput] = useState(systemSettings.bannerActive);

  // Member search & filters
  const [memberSearch, setMemberSearch] = useState('');
  const [editingMemberRoles, setEditingMemberRoles] = useState<User | null>(null);
  const [editOfficerRoleSelect, setEditOfficerRoleSelect] = useState<OfficerRole>('None');
  const [editProjectHeadTags, setEditProjectHeadTags] = useState<string[]>([]);
  const [newProjectTagInput, setNewProjectTagInput] = useState('');

  // Ledger Audit state
  const [auditFilterMember, setAuditFilterMember] = useState<string>('all');
  const [auditFilterStatus, setAuditFilterStatus] = useState<string>('all');
  const [editingEntry, setEditingEntry] = useState<MLogEntry | null>(null);
  const [editEntryCodes, setEditEntryCodes] = useState<string[]>([]);
  const [editEntryRemarks, setEditEntryRemarks] = useState('');
  const [editEntryEventTitle, setEditEntryEventTitle] = useState('');
  const [editEntryStatus, setEditEntryStatus] = useState<'verified' | 'pending' | 'rejected'>('verified');

  // Proof inspection modal
  const [inspectProofUrl, setInspectProofUrl] = useState<string | null>(null);

  // File upload ref for SuperAdmin logo
  const logoFileRef = useRef<HTMLInputElement>(null);

  if (!currentUser?.isOfficer) {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-3xl">
        <ShieldAlert className="w-10 h-10 text-rose-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-white">Restricted Officer Zone</h2>
        <p className="text-xs text-slate-400 mt-1">
          This hub is restricted to elevated accounts (President, VP, Unit Heads, SuperAdmin).
        </p>
      </div>
    );
  }

  // Manual M.Log calculation & validation
  const manualValidation = validatePksSelection(manualCodes);
  const manualScore = calculatePksFromCodes(manualCodes);

  const toggleManualCode = (code: string) => {
    setManualCodes((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  };

  const handleManualMLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetMember = allUsers.find((u) => u.id === selectedMemberId);
    if (!targetMember || !manualEventTitle.trim() || manualCodes.length === 0) return;
    if (!manualValidation.isValid) return;

    addManualMLogEntry({
      memberId: targetMember.id,
      memberName: targetMember.fullName,
      memberAvatar: targetMember.avatarUrl,
      eventTitle: manualEventTitle.trim(),
      date: new Date().toISOString().split('T')[0],
      roleOrAward: manualRole.trim(),
      codes: manualCodes,
      pillarPoints: manualScore.breakdown,
      totalPoints: manualScore.total,
      remarks: manualRemarks.trim(),
      status: 'verified',
      verifiedBy: `${currentUser.fullName} (${currentUser.officerRole || currentUser.role})`,
      verifiedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    });

    setManualEventTitle('');
  };

  const handleCreateEventSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim()) return;

    createEvent({
      title: eventTitle.trim(),
      type: eventType,
      date: eventDate,
      time: eventTime,
      location: eventLocation,
      description: eventDescription,
      bannerUrl: eventBanner,
      status: 'upcoming',
      isContest,
      contestPrize: isContest ? contestPrize : undefined,
      contestDeadline: isContest ? eventDate : undefined,
      eligibleCodes: eligibleCodes,
    });

    setEventTitle('');
    setEventDescription('');
  };

  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newFullName.trim()) return;

    const projectHeadList = newProjectHeadInput
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean);

    const isOff = newOfficerRole !== 'None' || projectHeadList.length > 0;

    addMember({
      username: newUsername.trim(),
      password: newPassword,
      fullName: newFullName.trim(),
      nickname: newNickname.trim() || newFullName.split(' ')[0],
      avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80`,
      role: newOfficerRole !== 'None' ? newOfficerRole : 'Member',
      officerRole: newOfficerRole,
      projectHeadRoles: projectHeadList,
      isOfficer: isOff,
      creativeTags: newTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      gradeSection: newGrade,
      joinedDate: 'October 2026',
      bio: 'FPC creative contributor.',
    });

    setNewUsername('');
    setNewFullName('');
    setNewNickname('');
    setNewProjectHeadInput('');
    setNewOfficerRole('None');
  };

  const handleSaveSuperAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    updateSystemSettings({
      appName: appNameInput,
      schoolName: schoolNameInput,
      orgTagline: taglineInput,
      logoUrl: logoInput,
      academicYear: academicYearInput,
      announcementBanner: bannerInput,
      bannerActive: bannerActiveInput,
    });
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressedDataUrl = await compressImageFile(file, 400, 400, 0.8);
      setLogoInput(compressedDataUrl);
    } catch (err) {
      console.warn('Fallback logo upload:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoInput(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const openDualRolesModal = (user: User) => {
    setEditingMemberRoles(user);
    setEditOfficerRoleSelect(user.officerRole || 'None');
    setEditProjectHeadTags(user.projectHeadRoles || []);
    setNewProjectTagInput('');
  };

  const handleSaveDualRoles = () => {
    if (!editingMemberRoles) return;
    updateMemberDualRoles(editingMemberRoles.id, editOfficerRoleSelect, editProjectHeadTags);
    setEditingMemberRoles(null);
  };

  const handleAddProjectTag = () => {
    if (!newProjectTagInput.trim()) return;
    if (!editProjectHeadTags.includes(newProjectTagInput.trim())) {
      setEditProjectHeadTags([...editProjectHeadTags, newProjectTagInput.trim()]);
    }
    setNewProjectTagInput('');
  };

  const handleRemoveProjectTag = (tag: string) => {
    setEditProjectHeadTags(editProjectHeadTags.filter((t) => t !== tag));
  };

  // Open Edit MLog Entry
  const openEditEntryModal = (entry: MLogEntry) => {
    setEditingEntry(entry);
    setEditEntryCodes(entry.codes);
    setEditEntryRemarks(entry.remarks);
    setEditEntryEventTitle(entry.eventTitle);
    setEditEntryStatus(entry.status);
  };

  const handleSaveEditEntry = () => {
    if (!editingEntry) return;
    const calc = calculatePksFromCodes(editEntryCodes);
    updateMLogEntry(editingEntry.id, {
      codes: editEntryCodes,
      pillarPoints: calc.breakdown,
      totalPoints: calc.total,
      remarks: editEntryRemarks,
      eventTitle: editEntryEventTitle,
      status: editEntryStatus,
    });
    setEditingEntry(null);
  };

  const toggleEditEntryCode = (code: string) => {
    setEditEntryCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const officerRolesList: OfficerRole[] = [
    'None',
    'President',
    'VPIA',
    'VPCA',
    'Secretary',
    'Treasurer',
    'PEBU Head',
    'Creative Group Head',
    'Project Head',
    'SuperAdmin',
  ];

  // Target member calculation for manual M.Log tool
  const currentTargetMember = allUsers.find((u) => u.id === selectedMemberId);
  const currentTargetPoints = currentTargetMember ? getMemberPks(currentTargetMember.id) : 0;
  const currentTargetRank = currentTargetMember ? getMemberRank(currentTargetMember.id) : null;
  const projectedTargetPoints = currentTargetPoints + (manualValidation.isValid ? manualScore.total : 0);
  const projectedTargetRank = getRankTierForPks(projectedTargetPoints);

  // Filtered M.Log for Ledger Audit
  const auditEntries = mLogEntries.filter((entry) => {
    if (auditFilterMember !== 'all' && entry.memberId !== auditFilterMember) return false;
    if (auditFilterStatus !== 'all' && entry.status !== auditFilterStatus) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-200">
      {/* Admin Hub Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
                Restricted Access
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono font-semibold">
                {currentUser.officerRole || currentUser.role}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                Dual Status: {getMemberRank(currentUser.id).name}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <span>FPC Hub Management Center</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Verify M.Log ledger requests, manage dual roles, publish production shoots, and audit automated PKS rank progressions.
            </p>
          </div>
        </div>

        {/* Sub-Navigation Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto mt-5 pt-4 border-t border-slate-800/80">
          <button
            onClick={() => setAdminSection('queue')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border ${
              adminSection === 'queue'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Verification Queue</span>
            {pendingEntries.length > 0 && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                  adminSection === 'queue'
                    ? 'bg-slate-950 text-amber-400'
                    : 'bg-rose-500 text-white'
                }`}
              >
                {pendingEntries.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setAdminSection('manual_mlog')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 border ${
              adminSection === 'manual_mlog'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Manual M.Log Entry</span>
          </button>

          <button
            onClick={() => setAdminSection('ledger_audit')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 border ${
              adminSection === 'ledger_audit'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Ledger Audit & Adjustments</span>
          </button>

          <button
            onClick={() => setAdminSection('create_event')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 border ${
              adminSection === 'create_event'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <CalendarPlus className="w-3.5 h-3.5" />
            <span>Create Event / Contest</span>
          </button>

          <button
            onClick={() => setAdminSection('members')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 border ${
              adminSection === 'members'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Members & Dual Roles</span>
          </button>

          {/* SuperAdmin Panel Tab */}
          {currentUser.role === 'SuperAdmin' && (
            <button
              onClick={() => setAdminSection('superadmin')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 border ${
                adminSection === 'superadmin'
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                  : 'bg-slate-950 text-amber-400/90 border-amber-500/30 hover:text-amber-300'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>SuperAdmin Panel</span>
            </button>
          )}
        </div>
      </div>

      {/* SECTION 1: Verification Queue */}
      {adminSection === 'queue' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Officer Verification Queue</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                  {pendingEntries.length} Pending
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Approving entries dynamically credits PKS points to the member&rsquo;s ledger and immediately triggers rank badge promotions.
              </p>
            </div>
          </div>

          {pendingEntries.length === 0 ? (
            <div className="text-center py-12 bg-slate-950/40 rounded-2xl border border-slate-800 text-slate-400 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
              <div className="font-semibold text-slate-300">Verification Queue is Clear</div>
              <div className="text-slate-500 mt-1">All member M.Log submissions have been reviewed.</div>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingEntries.map((entry) => {
                const currentMemberPoints = getMemberPks(entry.memberId);
                const currentMemberRank = getMemberRank(entry.memberId);
                const projectedMemberPoints = currentMemberPoints + entry.totalPoints;
                const projectedMemberRank = getRankTierForPks(projectedMemberPoints);
                const isRankAdvancement = projectedMemberRank.id !== currentMemberRank.id;

                return (
                  <div
                    key={entry.id}
                    className="p-4 sm:p-5 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-3">
                        <img
                          src={entry.memberAvatar}
                          alt={entry.memberName}
                          className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-white">{entry.memberName}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${currentMemberRank.badgeColor}`}>
                              {currentMemberRank.name} ({currentMemberPoints} PKS)
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                            <span>{entry.date}</span>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-400/90 font-medium">{entry.roleOrAward}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-sm font-bold text-slate-200 mt-1">{entry.eventTitle}</div>

                      <p className="text-xs text-slate-400 leading-relaxed bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/60">
                        &ldquo;{entry.remarks}&rdquo;
                      </p>

                      <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                        <span className="text-slate-500 font-semibold uppercase text-[10px]">
                          Requested Codes:
                        </span>
                        {entry.codes.map((code) => (
                          <span
                            key={code}
                            className="font-mono text-xs px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-300 font-bold"
                          >
                            {code}
                          </span>
                        ))}

                        {entry.proofUrl && (
                          <button
                            type="button"
                            onClick={() => setInspectProofUrl(entry.proofUrl || null)}
                            className="text-xs text-amber-400 hover:underline flex items-center gap-1 cursor-pointer ml-2"
                          >
                            <span>Preview Proof File</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        )}
                      </div>

                      {/* Rank Advancement Preview */}
                      <div className="mt-2 p-2 rounded-xl bg-slate-900/80 border border-slate-800/80 flex items-center gap-2 text-xs">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-slate-400">Approval Impact:</span>
                        <span className="font-mono text-slate-200 font-semibold">
                          {currentMemberPoints} → {projectedMemberPoints} PKS
                        </span>
                        {isRankAdvancement ? (
                          <span className="ml-auto font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-600/40 px-2 py-0.5 rounded text-[11px] animate-pulse">
                            🎉 Dynamic Promotion to {projectedMemberRank.name}!
                          </span>
                        ) : (
                          <span className="ml-auto text-slate-400 text-[11px]">
                            Remains {currentMemberRank.name}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions & Point Value */}
                    <div className="flex md:flex-col items-center md:items-end justify-between gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800">
                      <div className="text-left md:text-right">
                        <div className="text-[10px] text-slate-500 uppercase tracking-wider">
                          Credit Value
                        </div>
                        <div className="text-xl font-bold font-mono text-amber-400 tabular-nums">
                          +{entry.totalPoints} PKS
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => verifyMLogEntry(entry.id, 'rejected')}
                          className="px-3 py-1.5 rounded-xl bg-slate-900 border border-rose-800/60 hover:bg-rose-950/60 text-rose-300 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => verifyMLogEntry(entry.id, 'verified')}
                          className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white text-xs font-semibold shadow-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Verify & Credit</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* SECTION 2: Manual M.Log Tool */}
      {adminSection === 'manual_mlog' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Officer Manual M.Log Assignment Tool</span>
            </h2>
            <p className="text-xs text-slate-400">
              Directly credit a member&rsquo;s verified M.Log ledger with official 4-pillar codes. Automatically triggers rank badge updates in real time.
            </p>
          </div>

          <form onSubmit={handleManualMLogSubmit} className="space-y-4 max-w-2xl">
            {/* Member Select */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Member
              </label>
              <select
                value={selectedMemberId}
                onChange={(e) => setSelectedMemberId(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
              >
                {allUsers.map((u) => {
                  const pks = getMemberPks(u.id);
                  const rank = getMemberRank(u.id);
                  return (
                    <option key={u.id} value={u.id}>
                      {u.fullName} · {rank.name} ({pks} PKS){u.officerRole && u.officerRole !== 'None' ? ` [${u.officerRole}]` : ''}
                    </option>
                  );
                })}
              </select>

              {/* Dynamic Rank & Projected Promotion Preview */}
              {currentTargetMember && currentTargetRank && (
                <div className="mt-2.5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">Current Standing:</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${currentTargetRank.badgeColor}`}>
                      {currentTargetRank.name} ({currentTargetPoints} PKS)
                    </span>
                    {currentTargetMember.officerRole && currentTargetMember.officerRole !== 'None' && (
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-medium">
                        {currentTargetMember.officerRole}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 font-mono">
                    <span className="text-slate-400">After Credit:</span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded ${
                        projectedTargetRank.id !== currentTargetRank.id
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50'
                          : 'text-amber-400'
                      }`}
                    >
                      {projectedTargetRank.name} ({projectedTargetPoints} PKS)
                      {projectedTargetRank.id !== currentTargetRank.id && ' 🎉 Rank Promotion!'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Event Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Event / Project Title
              </label>
              <input
                type="text"
                required
                value={manualEventTitle}
                onChange={(e) => setManualEventTitle(e.target.value)}
                placeholder="e.g. Foundation Day Opening Ceremony Full Coverage"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Role */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Role or Designation
              </label>
              <input
                type="text"
                required
                value={manualRole}
                onChange={(e) => setManualRole(e.target.value)}
                placeholder="e.g. Lead Videographer / Shoot Director"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500"
              />
            </div>

            {/* Pillar Code Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-300">
                  Select PKS Pillar Codes ({manualCodes.length} selected)
                </label>
                <div className="text-xs font-mono font-bold text-amber-400">
                  Sum: +{manualScore.total} PKS
                </div>
              </div>

              {!manualValidation.isValid && (
                <div className="mb-3 p-3 rounded-xl bg-rose-950/70 border border-rose-800/80 text-rose-200 text-xs space-y-1">
                  {manualValidation.errors.map((err, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>{err}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 max-h-56 overflow-y-auto">
                {(['C', 'P', 'B', 'R', 'S'] as const).map((cat) => (
                  <div key={cat} className="space-y-1">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      {cat}-Codes
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {PILLAR_CODES.filter((c) => c.category === cat).map((c) => {
                        const isSelected = manualCodes.includes(c.code);
                        return (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => toggleManualCode(c.code)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-all cursor-pointer flex items-center gap-1 border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-400'
                                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <span>{c.code}</span>
                            <span className="text-[10px] font-normal opacity-85">+{c.points}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Remarks */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Officer Remarks & Deliverables
              </label>
              <textarea
                rows={2}
                value={manualRemarks}
                onChange={(e) => setManualRemarks(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>

            <button
              type="submit"
              disabled={!manualValidation.isValid || manualCodes.length === 0}
              className="py-3 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-40 cursor-pointer"
            >
              Credit M.Log Ledger (+{manualScore.total} PKS) & Promote
            </button>
          </form>
        </section>
      )}

      {/* SECTION 3: Ledger Audit & Adjustments */}
      {adminSection === 'ledger_audit' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>M.Log Ledger Audit & Live Adjustments</span>
              </h2>
              <p className="text-xs text-slate-400">
                Inspect, modify codes, or retract entries. Point changes and automatic rank badges recalculate immediately.
              </p>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={auditFilterMember}
                onChange={(e) => setAuditFilterMember(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              >
                <option value="all">All Members</option>
                {allUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName}
                  </option>
                ))}
              </select>

              <select
                value={auditFilterStatus}
                onChange={(e) => setAuditFilterStatus(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              >
                <option value="all">All Statuses</option>
                <option value="verified">Verified Only</option>
                <option value="pending">Pending Only</option>
                <option value="rejected">Rejected Only</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Member</th>
                  <th className="py-2.5 px-3">Event / Task</th>
                  <th className="py-2.5 px-3">Codes & Breakdown</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Points</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {auditEntries.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No M.Log records match your filter criteria.
                    </td>
                  </tr>
                ) : (
                  auditEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-3 font-mono text-slate-400">{entry.date}</td>
                      <td className="py-3 px-3 flex items-center gap-2">
                        <img
                          src={entry.memberAvatar}
                          alt={entry.memberName}
                          className="w-6 h-6 rounded-lg object-cover"
                        />
                        <span className="font-semibold text-slate-200">{entry.memberName}</span>
                      </td>
                      <td className="py-3 px-3 text-white max-w-[200px] truncate">
                        <div>{entry.eventTitle}</div>
                        <div className="text-[10px] text-amber-400/80">{entry.roleOrAward}</div>
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <div className="flex flex-wrap gap-1">
                          {entry.codes.map((c) => (
                            <span key={c} className="px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-amber-300 text-[10px]">
                              {c}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                            entry.status === 'verified'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : entry.status === 'pending'
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {entry.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-amber-400 tabular-nums">
                        +{entry.totalPoints}
                      </td>
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditEntryModal(entry)}
                            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
                            title="Edit codes & adjust score"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteMLogEntry(entry.id)}
                            className="p-1 rounded bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 transition-colors cursor-pointer"
                            title="Delete entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* SECTION 4: Create Event / Contest */}
      {adminSection === 'create_event' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <CalendarPlus className="w-4 h-4 text-amber-400" />
              <span>Publish Event, Shoot Coverage, or Contest</span>
            </h2>
            <p className="text-xs text-slate-400">
              Create call sheets and competitions displayed directly on member dashboards.
            </p>
          </div>

          <form onSubmit={handleCreateEventSubmit} className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  required
                  value={eventTitle}
                  onChange={(e) => setEventTitle(e.target.value)}
                  placeholder="e.g. Science Fair Video Reel & Photo Coverage"
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Event Classification
                </label>
                <select
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value as EventType)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
                >
                  <option value="shoot">Shoot & Media Coverage</option>
                  <option value="contest">Photo / Design Contest</option>
                  <option value="workshop">Multimedia Workshop</option>
                  <option value="meeting">General Assembly</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Call Time</label>
                <input
                  type="text"
                  required
                  value={eventTime}
                  onChange={(e) => setEventTime(e.target.value)}
                  placeholder="8:00 AM – 3:00 PM"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
                <input
                  type="text"
                  required
                  value={eventLocation}
                  onChange={(e) => setEventLocation(e.target.value)}
                  placeholder="SJNHS Gymnasium"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Call Sheet & Briefing
              </label>
              <textarea
                rows={3}
                required
                value={eventDescription}
                onChange={(e) => setEventDescription(e.target.value)}
                placeholder="Details on camera rigs needed, shot list, coverage guidelines, and schedule..."
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>

            {/* Contest Toggle */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isContest}
                  onChange={(e) => setIsContest(e.target.checked)}
                  className="w-4 h-4 accent-amber-500 rounded"
                />
                <span className="text-xs font-bold text-white">
                  Mark as Active Photo / Design Competition
                </span>
              </label>

              {isContest && (
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Prize & Recognition Details
                  </label>
                  <input
                    type="text"
                    value={contestPrize}
                    onChange={(e) => setContestPrize(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white"
                  />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-semibold text-slate-300">
                  Eligible PKS Codes ({eligibleCodes.length} selected)
                </label>
                <div className="flex items-center gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setEligibleCodes(['C1', 'C2', 'P3', 'P4', 'B2', 'S2'])}
                    className="text-amber-400 hover:text-amber-300 underline cursor-pointer"
                  >
                    Coverage Preset
                  </button>
                  <span className="text-slate-600">·</span>
                  <button
                    type="button"
                    onClick={() => setEligibleCodes(['C3', 'P5', 'R1', 'R2', 'S4'])}
                    className="text-amber-400 hover:text-amber-300 underline cursor-pointer"
                  >
                    Contest Preset
                  </button>
                  <span className="text-slate-600">·</span>
                  <button
                    type="button"
                    onClick={() => setEligibleCodes([])}
                    className="text-slate-400 hover:text-slate-300 underline cursor-pointer"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {/* Categorized Code Buttons */}
              <div className="space-y-2.5 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 max-h-56 overflow-y-auto">
                {(['C', 'P', 'B', 'R', 'S'] as const).map((cat) => (
                  <div key={cat} className="space-y-1.5">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                      {cat}-Codes
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {PILLAR_CODES.filter((c) => c.category === cat).map((c) => {
                        const isSelected = eligibleCodes.includes(c.code);
                        return (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => toggleEligibleCode(c.code)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-all cursor-pointer flex items-center gap-1 border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm font-bold'
                                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <span>{c.code}</span>
                            <span className="text-[10px] font-normal opacity-85">+{c.points}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="py-3 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer"
            >
              Publish Event to FPC Hub
            </button>
          </form>
        </section>
      )}

      {/* SECTION 5: Members & Dual Roles Manager */}
      {adminSection === 'members' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                <span>Member Directory & Dual Roles Manager</span>
              </h2>
              <p className="text-xs text-slate-400">
                Manage dual status: members retain their dynamic M.Log creative rank badge while holding concurrent officer or project head roles.
              </p>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={memberSearch}
                onChange={(e) => setMemberSearch(e.target.value)}
                placeholder="Search member or role..."
                className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500"
              />
            </div>
          </div>

          {/* Members Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Member</th>
                  <th className="py-2.5 px-3">Dynamic Creative Rank</th>
                  <th className="py-2.5 px-3">Concurrent Officer Post</th>
                  <th className="py-2.5 px-3">Project Head Assignments</th>
                  <th className="py-2.5 px-3">Admin Access</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {allUsers
                  .filter(
                    (u) =>
                      u.fullName.toLowerCase().includes(memberSearch.toLowerCase()) ||
                      u.username.toLowerCase().includes(memberSearch.toLowerCase()) ||
                      (u.officerRole && u.officerRole.toLowerCase().includes(memberSearch.toLowerCase())) ||
                      (u.projectHeadRoles && u.projectHeadRoles.some((p) => p.toLowerCase().includes(memberSearch.toLowerCase())))
                  )
                  .map((user) => {
                    const pks = getMemberPks(user.id);
                    const rank = getMemberRank(user.id);

                    return (
                      <tr key={user.id} className="hover:bg-slate-800/30">
                        {/* Member Identity */}
                        <td className="py-3 px-3 flex items-center gap-2.5">
                          <img
                            src={user.avatarUrl}
                            alt={user.nickname}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-700"
                          />
                          <div>
                            <div className="font-semibold text-slate-200">{user.fullName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">@{user.username} · {user.gradeSection}</div>
                          </div>
                        </td>

                        {/* Dynamic Creative Rank (from M.Log ledger) */}
                        <td className="py-3 px-3">
                          <div className="flex flex-col items-start gap-0.5">
                            <span className={`text-xs font-bold px-2 py-0.5 rounded border ${rank.badgeColor} ${rank.borderColor}`}>
                              {rank.name}
                            </span>
                            <span className="text-[10px] font-mono text-amber-400/90 font-semibold">
                              {pks} PKS (Verified M.Log)
                            </span>
                          </div>
                        </td>

                        {/* Concurrent Officer Post */}
                        <td className="py-3 px-3">
                          {user.officerRole && user.officerRole !== 'None' ? (
                            <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/40 text-amber-300">
                              {user.officerRole}
                            </span>
                          ) : (
                            <span className="text-slate-500 text-xs italic">Regular Member</span>
                          )}
                        </td>

                        {/* Concurrent Project Head Roles */}
                        <td className="py-3 px-3">
                          {user.projectHeadRoles && user.projectHeadRoles.length > 0 ? (
                            <div className="flex flex-wrap gap-1 max-w-[220px]">
                              {user.projectHeadRoles.map((pr) => (
                                <span
                                  key={pr}
                                  className="text-[10px] font-medium px-2 py-0.5 rounded bg-purple-500/15 border border-purple-500/40 text-purple-300 truncate"
                                >
                                  {pr}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-slate-600 text-[11px]">—</span>
                          )}
                        </td>

                        {/* Admin Access Status */}
                        <td className="py-3 px-3">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              user.isOfficer
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {user.isOfficer ? 'Admin Access' : 'Standard'}
                          </span>
                        </td>

                        {/* Actions: Edit Dual Roles */}
                        <td className="py-3 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => openDualRolesModal(user)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-colors inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit Dual Roles</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Provision New Member Account (Admin Only) */}
          <div className="pt-4 border-t border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
              Provision New Member Account with Dual Status (Admin Only)
            </h3>
            <form onSubmit={handleCreateMember} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={newFullName}
                  onChange={(e) => setNewFullName(e.target.value)}
                  placeholder="e.g. Maria Clara Santos"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  required
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="e.g. maria_santos"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Initial Password
                </label>
                <input
                  type="text"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Concurrent Officer Post
                </label>
                <select
                  value={newOfficerRole}
                  onChange={(e) => setNewOfficerRole(e.target.value as OfficerRole)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                >
                  {officerRolesList.map((r) => (
                    <option key={r} value={r}>
                      {r === 'None' ? 'None (Regular Member Identity)' : r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Concurrent Project Head Roles (Comma separated)
                </label>
                <input
                  type="text"
                  value={newProjectHeadInput}
                  onChange={(e) => setNewProjectHeadInput(e.target.value)}
                  placeholder="e.g. Intramurals Courtside, Horizon Reel"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Grade & Section
                </label>
                <input
                  type="text"
                  value={newGrade}
                  onChange={(e) => setNewGrade(e.target.value)}
                  placeholder="Grade 11 STEM-B"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
              </div>

              <div className="sm:col-span-3 flex justify-end pt-2">
                <button
                  type="submit"
                  className="py-2.5 px-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  Create Member Account with Dual Status
                </button>
              </div>
            </form>
          </div>
        </section>
      )}

      {/* SECTION 6: SuperAdmin Global Settings */}
      {adminSection === 'superadmin' && currentUser.role === 'SuperAdmin' && (
        <section className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-amber-400" />
                <span>SuperAdmin Global System Configuration</span>
              </h2>
              <p className="text-xs text-slate-400">
                Exclusively accessible to SuperAdmin. Updates global branding, logos, and organizational metadata.
              </p>
            </div>
            <span className="text-[10px] font-bold text-rose-400 bg-rose-950/70 border border-rose-800/60 px-2 py-0.5 rounded">
              SuperAdmin Exclusive
            </span>
          </div>

          <form onSubmit={handleSaveSuperAdmin} className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Official Web App Name
                </label>
                <input
                  type="text"
                  required
                  value={appNameInput}
                  onChange={(e) => setAppNameInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  School / Institution
                </label>
                <input
                  type="text"
                  required
                  value={schoolNameInput}
                  onChange={(e) => setSchoolNameInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Organization Tagline
                </label>
                <input
                  type="text"
                  value={taglineInput}
                  onChange={(e) => setTaglineInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Academic Year
                </label>
                <input
                  type="text"
                  value={academicYearInput}
                  onChange={(e) => setAcademicYearInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* App Logo Control */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Official FPC Logo / Emblem
              </label>
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl overflow-hidden border border-amber-500/40 bg-slate-950 shrink-0">
                  <img src={logoInput} alt="Logo" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 space-y-1.5">
                  <input
                    type="text"
                    value={logoInput}
                    onChange={(e) => setLogoInput(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono"
                    placeholder="Image URL or generated asset path..."
                  />
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => logoFileRef.current?.click()}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 flex items-center gap-1 cursor-pointer"
                    >
                      <Upload className="w-3 h-3" />
                      <span>Upload New Image</span>
                    </button>
                    <input
                      ref={logoFileRef}
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Announcement Banner */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-300">
                  Broadcast Announcement Banner
                </label>
                <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bannerActiveInput}
                    onChange={(e) => setBannerActiveInput(e.target.checked)}
                    className="w-3.5 h-3.5 accent-amber-500 rounded"
                  />
                  <span>Show Banner</span>
                </label>
              </div>
              <textarea
                rows={2}
                value={bannerInput}
                onChange={(e) => setBannerInput(e.target.value)}
                placeholder="Message displayed across all member screens..."
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>

            <button
              type="submit"
              className="py-3 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer"
            >
              Save SuperAdmin System Settings
            </button>
          </form>
        </section>
      )}

      {/* DUAL ROLES EDIT MODAL */}
      {editingMemberRoles && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={editingMemberRoles.avatarUrl}
                  alt={editingMemberRoles.nickname}
                  className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                />
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Manage Dual Roles</span>
                    <span className="text-xs text-amber-400 font-normal">
                      ({editingMemberRoles.fullName})
                    </span>
                  </h3>
                  <div className="text-xs text-slate-400">
                    Dynamic Rank: <strong>{getMemberRank(editingMemberRoles.id).name}</strong> ({getMemberPks(editingMemberRoles.id)} PKS)
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingMemberRoles(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Note on Dual Status */}
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
                <strong>Dual Status Active:</strong> Assigning an officer post or project head role preserves their regular creative rank identity earned via the 4-Pillar M.Log ledger.
              </div>

              {/* Officer Role */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Concurrent Club Officer Post
                </label>
                <select
                  value={editOfficerRoleSelect}
                  onChange={(e) => setEditOfficerRoleSelect(e.target.value as OfficerRole)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
                >
                  {officerRolesList.map((r) => (
                    <option key={r} value={r}>
                      {r === 'None' ? 'None (Pure Member Identity)' : r}
                    </option>
                  ))}
                </select>
              </div>

              {/* Project Head Tags */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Concurrent Project Head Assignments
                </label>
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="text"
                    value={newProjectTagInput}
                    onChange={(e) => setNewProjectTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddProjectTag();
                      }
                    }}
                    placeholder="e.g. Intramurals Courtside, Campus Docu..."
                    className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddProjectTag}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 min-h-8 p-2 rounded-xl bg-slate-950 border border-slate-800">
                  {editProjectHeadTags.length === 0 ? (
                    <span className="text-slate-500 italic">No project head roles currently assigned.</span>
                  ) : (
                    editProjectHeadTags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-300 flex items-center gap-1"
                      >
                        <span>{tag}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveProjectTag(tag)}
                          className="hover:text-rose-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Summary Preview */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">
                  Member Display Preview:
                </span>
                <div className="flex flex-wrap items-center gap-2 pt-0.5">
                  <span className={`px-2 py-0.5 rounded font-bold ${getMemberRank(editingMemberRoles.id).badgeColor}`}>
                    {getMemberRank(editingMemberRoles.id).name}
                  </span>
                  {editOfficerRoleSelect !== 'None' && (
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                      Officer: {editOfficerRoleSelect}
                    </span>
                  )}
                  {editProjectHeadTags.length > 0 && (
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                      Project Head: {editProjectHeadTags.join(', ')}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingMemberRoles(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveDualRoles}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
              >
                Save Dual Roles
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT M.LOG ENTRY MODAL */}
      {editingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-amber-400" />
                  <span>Adjust M.Log Entry</span>
                </h3>
                <div className="text-xs text-slate-400">
                  Editing record for <strong>{editingEntry.memberName}</strong>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingEntry(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Event / Title</label>
                <input
                  type="text"
                  value={editEntryEventTitle}
                  onChange={(e) => setEditEntryEventTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-300">
                    Assigned 4-Pillar Codes
                  </label>
                  <span className="font-mono text-amber-400 font-bold">
                    +{calculatePksFromCodes(editEntryCodes).total} PKS
                  </span>
                </div>
                <div className="space-y-1.5 p-2.5 rounded-xl bg-slate-950 border border-slate-800 max-h-40 overflow-y-auto">
                  {(['C', 'P', 'B', 'R', 'S'] as const).map((cat) => (
                    <div key={cat} className="flex flex-wrap items-center gap-1">
                      <span className="text-[10px] text-slate-400 font-bold w-12">{cat}-Codes:</span>
                      {PILLAR_CODES.filter((c) => c.category === cat).map((c) => {
                        const isSelected = editEntryCodes.includes(c.code);
                        return (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => toggleEditEntryCode(c.code)}
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold cursor-pointer border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-400'
                                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                            }`}
                          >
                            {c.code} (+{c.points})
                          </button>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Verification Status</label>
                <select
                  value={editEntryStatus}
                  onChange={(e) =>
                    setEditEntryStatus(e.target.value as 'verified' | 'pending' | 'rejected')
                  }
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
                >
                  <option value="verified">Verified (Points Count toward Rank)</option>
                  <option value="pending">Pending</option>
                  <option value="rejected">Rejected (0 Points)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Remarks</label>
                <textarea
                  rows={2}
                  value={editEntryRemarks}
                  onChange={(e) => setEditEntryRemarks(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingEntry(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEditEntry}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
              >
                Apply Live Adjustments & Recalculate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Proof Lightbox Modal */}
      {inspectProofUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setInspectProofUrl(null)}
        >
          <div className="relative max-w-3xl w-full flex flex-col items-center">
            <img
              src={inspectProofUrl}
              alt="Verification Proof"
              className="max-h-[80vh] w-auto max-w-full rounded-2xl object-contain shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
