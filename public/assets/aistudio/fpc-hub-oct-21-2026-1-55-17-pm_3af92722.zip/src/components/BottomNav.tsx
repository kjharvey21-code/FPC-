import React from 'react';
import { useApp } from '../context/AppContext';
import { LayoutDashboard, Newspaper, User, ShieldAlert } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentUser } = useApp();

  if (!currentUser) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 px-2 pb-safe">
      <div
        className={`grid ${
          currentUser.isOfficer ? 'grid-cols-4' : 'grid-cols-3'
        } items-center h-16`}
      >
        <button
          onClick={() => setActiveTab('home')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer ${
            activeTab === 'home' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Dashboard"
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[11px] tracking-tight mt-1">Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('feed')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer ${
            activeTab === 'feed' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Feed"
        >
          <Newspaper className="w-5 h-5" />
          <span className="text-[11px] tracking-tight mt-1">Feed</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer ${
            activeTab === 'profile' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Accounts & M.Log"
        >
          <User className="w-5 h-5" />
          <span className="text-[11px] tracking-tight mt-1">Accounts</span>
        </button>

        {currentUser.isOfficer && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`min-h-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer ${
              activeTab === 'admin' ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="Admin Hub"
          >
            <ShieldAlert className="w-5 h-5" />
            <span className="text-[11px] tracking-tight mt-1">Admin</span>
          </button>
        )}
      </div>
    </nav>
  );
};
