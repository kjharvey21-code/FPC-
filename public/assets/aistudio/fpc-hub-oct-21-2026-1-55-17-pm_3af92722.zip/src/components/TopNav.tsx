import React from 'react';
import { useApp } from '../context/AppContext';
import { LogOut, ShieldAlert, Award } from 'lucide-react';
import { getRankTierForPks } from '../data/pksFramework';

export const TopNav: React.FC = () => {
  const { currentUser, logout, activeTab, setActiveTab, systemSettings, getMemberPks, getMemberRank } = useApp();

  if (!currentUser) return null;

  const totalPks = getMemberPks(currentUser.id);
  const rank = getMemberRank(currentUser.id);

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-900 border border-amber-500/30 flex items-center justify-center shrink-0">
            <img
              src={systemSettings.logoUrl}
              alt="FPC Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <button
            onClick={() => setActiveTab('home')}
            className="text-left font-bold tracking-tight text-white hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <span className="text-base sm:text-lg">{systemSettings.appName}</span>
            <span className="text-xs text-amber-400 font-medium hidden sm:inline">· First Peek</span>
          </button>
        </div>

        {/* Zone 2: Desktop Navigation Links (4 clean single-line links) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('home')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer py-1 ${
              activeTab === 'home' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('feed')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer py-1 ${
              activeTab === 'feed' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Feed
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer py-1 ${
              activeTab === 'profile' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Accounts & M.Log
          </button>

          {/* Admin tab is strictly visible ONLY to elevated roles */}
          {currentUser.isOfficer && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer py-1 flex items-center gap-1.5 ${
                activeTab === 'admin'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Admin Hub</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Primary Action / User Lockup */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-left transition-colors cursor-pointer group"
          >
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.nickname}
              className="w-7 h-7 rounded-lg object-cover border border-slate-700"
              referrerPolicy="no-referrer"
            />
            <div className="hidden sm:block text-left">
              <div className="text-xs font-semibold text-slate-200 group-hover:text-amber-300 transition-colors leading-none truncate max-w-[100px]">
                {currentUser.nickname}
              </div>
              <div className="text-[10px] text-amber-400/90 font-medium leading-none mt-1 flex items-center gap-1">
                <Award className="w-2.5 h-2.5" />
                <span>
                  {rank.name} ({totalPks} PKS)
                  {currentUser.officerRole && currentUser.officerRole !== 'None'
                    ? ` · ${currentUser.officerRole}`
                    : currentUser.projectHeadRoles && currentUser.projectHeadRoles.length > 0
                    ? ` · Project Head`
                    : ''}
                </span>
              </div>
            </div>
          </button>

          <button
            onClick={logout}
            title="Log Out"
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-900 border border-slate-800/80 transition-colors cursor-pointer"
            aria-label="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
