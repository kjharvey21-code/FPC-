import React from 'react';
import { useApp } from '../../context/AppContext';
import { EventAssignment } from '../../types';
import { X, Calendar, Clock, MapPin, Users, Award, Camera, CheckCircle2 } from 'lucide-react';

interface EventDetailsModalProps {
  event: EventAssignment;
  onClose: () => void;
  onOpenSubmitEntry?: () => void;
}

export const EventDetailsModal: React.FC<EventDetailsModalProps> = ({
  event,
  onClose,
  onOpenSubmitEntry,
}) => {
  const { currentUser, allUsers, toggleVolunteer } = useApp();

  const isAssigned = currentUser ? event.assignedCrewIds.includes(currentUser.id) : false;
  const isVolunteered = currentUser ? event.volunteerCrewIds.includes(currentUser.id) : false;

  const assignedUsers = allUsers.filter((u) => event.assignedCrewIds.includes(u.id));
  const volunteerUsers = allUsers.filter((u) => event.volunteerCrewIds.includes(u.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Banner with measured scrim */}
        <div className="relative h-44 sm:h-52 w-full bg-slate-950">
          <img
            src={event.bannerUrl}
            alt={event.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Event Status Badges */}
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs">
            <span className="font-semibold text-amber-400 uppercase tracking-wider text-[11px] bg-slate-950/80 px-2.5 py-1 rounded-lg border border-amber-500/30 backdrop-blur-xs">
              {event.type.toUpperCase()} · {event.status.toUpperCase()}
            </span>
            {event.isContest && (
              <span className="text-[11px] font-semibold text-rose-300 bg-rose-950/80 px-2.5 py-1 rounded-lg border border-rose-700/40 backdrop-blur-xs">
                Contest Active
              </span>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white leading-snug">{event.title}</h2>
            {/* Unboxed metadata line with typographic separators */}
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-2 font-medium">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                {event.date}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                {event.time}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                {event.location}
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            {event.description}
          </div>

          {/* Contest info */}
          {event.isContest && event.contestPrize && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/10 to-purple-500/10 border border-amber-500/30 text-xs">
              <div className="text-amber-400 font-semibold mb-1 flex items-center gap-1.5">
                <Award className="w-4 h-4" />
                <span>Contest Honor & Prize:</span>
              </div>
              <div className="text-slate-200">{event.contestPrize}</div>
            </div>
          )}

          {/* Eligible PKS Codes */}
          {event.eligibleCodes && event.eligibleCodes.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Eligible PKS Pillars for this Coverage
              </div>
              <div className="flex flex-wrap gap-1.5">
                {event.eligibleCodes.map((code) => (
                  <span
                    key={code}
                    className="font-mono text-xs px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-amber-400 font-medium"
                  >
                    {code}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Crew Roster */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <span>Assigned Media Crew ({assignedUsers.length})</span>
              {event.maxCrew && <span className="font-mono">Max: {event.maxCrew}</span>}
            </div>

            {assignedUsers.length === 0 ? (
              <div className="text-xs text-slate-500 italic p-3 bg-slate-950/40 rounded-xl border border-slate-800/60">
                No primary crew assigned yet. Officers are finalizing call sheet slots.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {assignedUsers.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-950/80 border border-slate-800"
                  >
                    <img
                      src={user.avatarUrl}
                      alt={user.nickname}
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-200 truncate">
                        {user.fullName}
                      </div>
                      <div className="text-[10px] text-amber-400 truncate">{user.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Volunteer Crew */}
          {volunteerUsers.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Volunteers ({volunteerUsers.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {volunteerUsers.map((u) => (
                  <div
                    key={u.id}
                    className="text-xs flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>{u.nickname}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950/70 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            {isAssigned && (
              <span className="text-amber-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> You are on the assigned crew
              </span>
            )}
            {!isAssigned && isVolunteered && (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> You are volunteered
              </span>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            {!isAssigned && (
              <button
                type="button"
                onClick={() => toggleVolunteer(event.id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                  isVolunteered
                    ? 'border-rose-700/60 text-rose-300 bg-rose-950/40 hover:bg-rose-900/50'
                    : 'border-slate-700 text-slate-200 bg-slate-800 hover:bg-slate-700'
                }`}
              >
                {isVolunteered ? 'Withdraw Volunteer' : 'Volunteer for Shoot'}
              </button>
            )}

            {event.isContest && onOpenSubmitEntry && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenSubmitEntry();
                }}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Submit Entry</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
