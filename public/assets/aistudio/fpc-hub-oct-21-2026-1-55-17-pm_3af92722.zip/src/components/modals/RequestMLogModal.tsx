import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { PILLAR_CODES, validatePksSelection, calculatePksFromCodes } from '../../data/pksFramework';
import { X, Upload, AlertCircle, Sparkles, CheckCircle2 } from 'lucide-react';
import { compressImageFile } from '../../utils/imageUtils';

interface RequestMLogModalProps {
  onClose: () => void;
}

export const RequestMLogModal: React.FC<RequestMLogModalProps> = ({ onClose }) => {
  const { submitMemberMLogRequest, events } = useApp();
  const [eventTitle, setEventTitle] = useState('');
  const [customEventTitle, setCustomEventTitle] = useState('');
  const [roleOrAward, setRoleOrAward] = useState('');
  const [selectedCodes, setSelectedCodes] = useState<string[]>(['C2', 'P3']);
  const [remarks, setRemarks] = useState('');
  const [proofUrl, setProofUrl] = useState<string>('/src/assets/images/fpc_event_intramurals_1792558823605.jpg');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validation = validatePksSelection(selectedCodes);
  const score = calculatePksFromCodes(selectedCodes);

  const finalEventTitle = eventTitle === 'custom' ? customEventTitle : eventTitle || events[0]?.title || '';

  const toggleCode = (code: string) => {
    setSelectedCodes((prev) => {
      if (prev.includes(code)) {
        return prev.filter((c) => c !== code);
      } else {
        return [...prev, code];
      }
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressedDataUrl = await compressImageFile(file, 1000, 1000, 0.72);
      setProofUrl(compressedDataUrl);
    } catch (err) {
      console.warn('Fallback proof read:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!finalEventTitle.trim() || !roleOrAward.trim() || selectedCodes.length === 0) return;
    if (!validation.isValid) return;

    submitMemberMLogRequest({
      eventTitle: finalEventTitle.trim(),
      roleOrAward: roleOrAward.trim(),
      codes: selectedCodes,
      remarks: remarks.trim(),
      proofUrl,
    });
    onClose();
  };

  const samplePresets = [
    { label: 'Intramurals Coverage', url: '/src/assets/images/fpc_event_intramurals_1792558823605.jpg' },
    { label: 'Photo Contest', url: '/src/assets/images/fpc_contest_streetphoto_1792558823968.jpg' },
    { label: 'Media Workshop', url: '/src/assets/images/fpc_workshop_cover_1792558823447.jpg' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-amber-400 tracking-wider uppercase">
              M.Log Workflow
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white">Log Activity / Request Verification</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Event Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Event or Project Title
            </label>
            <select
              value={eventTitle}
              onChange={(e) => setEventTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
            >
              <option value="">Select official event...</option>
              {events.map((ev) => (
                <option key={ev.id} value={ev.title}>
                  {ev.title} ({ev.date})
                </option>
              ))}
              <option value="custom">+ Other / External Competition / Milestone...</option>
            </select>

            {eventTitle === 'custom' && (
              <input
                type="text"
                required
                value={customEventTitle}
                onChange={(e) => setCustomEventTitle(e.target.value)}
                placeholder="Enter custom event or project name..."
                className="mt-2 w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            )}
          </div>

          {/* Role or Award */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Role Performed / Distinction Won
            </label>
            <input
              type="text"
              required
              value={roleOrAward}
              onChange={(e) => setRoleOrAward(e.target.value)}
              placeholder="e.g. Lead Courtside Photographer, Video Editor, or 1st Place Poster"
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Pillar Codes Selector with Real-time Rules Enforcement */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300">
                PKS Pillar Codes ({selectedCodes.length} selected)
              </label>
              <div className="text-xs font-mono font-bold text-amber-400">
                Total: +{score.total} PKS
              </div>
            </div>

            {/* Validation Errors Notice */}
            {!validation.isValid && (
              <div className="mb-3 p-3 rounded-xl bg-rose-950/70 border border-rose-800/80 text-rose-200 text-xs space-y-1">
                {validation.errors.map((err, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <span>{err}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Code Pills Categorized */}
            <div className="space-y-2.5 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 max-h-56 overflow-y-auto">
              {(['C', 'P', 'B', 'R', 'S'] as const).map((cat) => {
                const catCodes = PILLAR_CODES.filter((c) => c.category === cat);
                const catTitles = {
                  C: 'C-Codes (Creative Output)',
                  P: 'P-Codes (Participation)',
                  B: 'B-Codes (Leadership & Responsibility)',
                  R: 'R-Codes (Recognition & Awards)',
                  S: 'S-Codes (Special Distinction)',
                };

                return (
                  <div key={cat} className="space-y-1">
                    <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      {catTitles[cat]}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {catCodes.map((c) => {
                        const isSelected = selectedCodes.includes(c.code);
                        return (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => toggleCode(c.code)}
                            title={`${c.title} (+${c.points} PKS): ${c.description}`}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-all cursor-pointer flex items-center gap-1.5 border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm'
                                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                            }`}
                          >
                            <span>{c.code}</span>
                            <span className="text-[10px] font-sans font-normal opacity-90">
                              +{c.points}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              FPC Rule: One code per pillar per entry. No double counting (Leadership B-code replaces Participation P-code).
            </p>
          </div>

          {/* Proof Upload */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Proof File / Output Screenshot / Certificate
            </label>
            <div className="flex items-center gap-3">
              {proofUrl && (
                <div className="w-14 h-14 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shrink-0">
                  <img src={proofUrl} alt="Proof" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex-1">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 flex items-center gap-2 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-amber-400" />
                  <span>Choose file from device (Base64)</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>

            {/* Quick Sample Presets */}
            <div className="mt-1.5 flex items-center gap-1 text-[10px] text-slate-400">
              <span className="text-slate-500">Preset proof:</span>
              {samplePresets.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setProofUrl(preset.url)}
                  className="text-amber-400 hover:underline cursor-pointer"
                >
                  {preset.label} ·
                </button>
              ))}
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Production Remarks / Deliverables Link
            </label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Uploaded 20 raw RAW+JPEG to Google Drive. Edited final highlight reel in Premiere."
              className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
            <div className="text-xs text-slate-400">
              Credit: <span className="font-mono font-bold text-amber-400">+{score.total} PKS</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-slate-800 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!validation.isValid || selectedCodes.length === 0}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-40 cursor-pointer"
              >
                Submit for Verification
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
