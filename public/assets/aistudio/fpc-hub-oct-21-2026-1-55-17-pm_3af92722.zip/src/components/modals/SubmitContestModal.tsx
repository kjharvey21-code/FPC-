import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { EventAssignment } from '../../types';
import { X, Upload, Image as ImageIcon, Sparkles, Check } from 'lucide-react';
import { compressImageFile } from '../../utils/imageUtils';

interface SubmitContestModalProps {
  event: EventAssignment;
  onClose: () => void;
}

export const SubmitContestModal: React.FC<SubmitContestModalProps> = ({ event, onClose }) => {
  const { submitToContest } = useApp();
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [imagePreview, setImagePreview] = useState<string>('/src/assets/images/fpc_contest_streetphoto_1792558823968.jpg');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const samplePresets = [
    { label: 'Campus Shadows', url: '/src/assets/images/fpc_contest_streetphoto_1792558823968.jpg' },
    { label: 'Courtside Action', url: '/src/assets/images/fpc_event_intramurals_1792558823605.jpg' },
    { label: 'Creative Studio', url: '/src/assets/images/fpc_workshop_cover_1792558823447.jpg' },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const compressedDataUrl = await compressImageFile(file, 1200, 1200, 0.75);
      setImagePreview(compressedDataUrl);
    } catch (err) {
      console.warn('Image compression fallback:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !imagePreview) return;

    submitToContest({
      eventId: event.id,
      eventTitle: event.title,
      title: title.trim(),
      caption: caption.trim(),
      imageUrl: imagePreview,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-amber-400 tracking-wider uppercase">
              Contest Submission
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white line-clamp-1">{event.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Image Upload Area */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Photograph / Creative Artwork File
            </label>
            <div className="relative group rounded-2xl border-2 border-dashed border-slate-700 hover:border-amber-500/60 transition-colors overflow-hidden bg-slate-950/60 p-3 flex flex-col items-center justify-center min-h-[180px]">
              {imagePreview ? (
                <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-950">
                  <img
                    src={imagePreview}
                    alt="Upload Preview"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white text-xs font-semibold backdrop-blur-xs"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Change File</span>
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center text-center cursor-pointer p-6"
                >
                  <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-amber-400 mb-2">
                    <Upload className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-medium text-slate-200">
                    Click to browse or drop high-res image
                  </span>
                  <span className="text-[10px] text-slate-500 mt-1">PNG, JPG, WEBP up to 20MB</span>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {/* Quick Sample Presets */}
            <div className="mt-2 flex items-center gap-1.5 overflow-x-auto text-[11px] text-slate-400">
              <span className="shrink-0 flex items-center gap-1 text-[10px] text-slate-500">
                <Sparkles className="w-3 h-3 text-amber-400" /> Quick samples:
              </span>
              {samplePresets.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setImagePreview(preset.url)}
                  className={`px-2 py-0.5 rounded-lg border text-[10px] transition-colors whitespace-nowrap cursor-pointer ${
                    imagePreview === preset.url
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-800/80 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Artwork / Photo Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Shadows on the Arcade Path"
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Artist Statement / Technical Specs
            </label>
            <textarea
              rows={3}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Describe composition, camera settings (focal length, ISO, shutter), or creative concept..."
              className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 flex items-start gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-300">Automated PKS Reward:</strong> Submitting verified original work grants <span className="text-amber-400 font-semibold font-mono">+15 PKS (P5)</span> participation instantly upon verification.
            </div>
          </div>

          {/* Footer Action */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-800 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !imagePreview || isUploading}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
            >
              Submit Official Entry
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
