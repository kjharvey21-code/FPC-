import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lock, User as UserIcon, Eye, EyeOff, ShieldCheck, ArrowRight, Sparkles, AlertTriangle } from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { login, systemSettings, allUsers } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDemoGuide, setShowDemoGuide] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!username.trim()) {
      setErrorMessage('Please enter your FPC username.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const result = login(username, password);
      if (!result.success) {
        setErrorMessage(result.message || 'Login failed. Please check your credentials.');
      }
      setIsSubmitting(false);
    }, 200);
  };

  const handleFillDemo = (demoUsername: string, demoPassword = 'fpc2026') => {
    setUsername(demoUsername);
    setPassword(demoPassword);
    setErrorMessage('');
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-center items-center px-4 py-8 relative overflow-hidden">
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md relative z-10 flex flex-col items-center">
        {/* Brand Lockup */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-20 h-20 rounded-2xl overflow-hidden border border-amber-500/30 shadow-2xl shadow-amber-500/10 mb-4 bg-slate-900 p-1">
            <img
              src={systemSettings.logoUrl}
              alt="First Peek Creatives Emblem"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>{systemSettings.appName}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xs font-medium">
            {systemSettings.schoolName}
          </p>
          <div className="flex items-center gap-2 text-xs text-amber-400/90 font-medium mt-1">
            <span>First Peek Creatives</span>
            <span aria-hidden="true">·</span>
            <span>{systemSettings.academicYear}</span>
          </div>
        </div>

        {/* Login Card */}
        <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-slate-100">Member & Officer Sign In</h2>
            <p className="text-xs text-slate-400 mt-1">
              Enter your Admin-assigned credentials to access your verified M.Log portal.
            </p>
          </div>

          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-rose-950/60 border border-rose-800/60 text-rose-200 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Username or ID
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. member or kent"
                  autoComplete="username"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold text-sm rounded-xl transition-all shadow-lg shadow-amber-500/20 active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer mt-2 disabled:opacity-50"
            >
              <span>{isSubmitting ? 'Authenticating...' : 'Sign In to FPC Hub'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Security Notice */}
          <div className="mt-6 pt-5 border-t border-slate-800/80 flex items-center justify-between text-slate-500 text-[11px]">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400/80" />
              <span>Role-Based FPC Security</span>
            </div>
            <span>No self-registration</span>
          </div>
        </div>

        {/* Demo Accounts Helper Accordion */}
        <div className="w-full mt-4">
          <button
            onClick={() => setShowDemoGuide(!showDemoGuide)}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900/60 border border-slate-800/70 text-slate-400 hover:text-amber-300 text-xs flex items-center justify-between transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Demo Testing Accounts (1-Click Fill)</span>
            </div>
            <span className="text-[10px] font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-300">
              {showDemoGuide ? 'Hide' : 'Show Roster'}
            </span>
          </button>

          {showDemoGuide && (
            <div className="mt-2 p-3 bg-slate-900/90 border border-slate-800 rounded-2xl text-xs space-y-2 backdrop-blur-md animate-in fade-in duration-200">
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Click any role below to prefill testing credentials (default password: <code className="text-amber-400 font-mono">fpc2026</code>):
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {allUsers.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => handleFillDemo(u.username, u.password || 'fpc2026')}
                    className="text-left p-2 rounded-lg bg-slate-950/70 border border-slate-800 hover:border-amber-500/40 hover:bg-slate-800/80 transition-colors cursor-pointer"
                  >
                    <div className="font-semibold text-slate-200 truncate">{u.nickname}</div>
                    <div className="text-[10px] text-amber-400/90 truncate">{u.role}</div>
                    <div className="text-[10px] text-slate-500 font-mono">user: {u.username}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* School Footer Note */}
        <p className="text-[11px] text-slate-600 text-center mt-6">
          San Jose National High School · Student Multimedia Arts Organization
        </p>
      </div>
    </div>
  );
};
